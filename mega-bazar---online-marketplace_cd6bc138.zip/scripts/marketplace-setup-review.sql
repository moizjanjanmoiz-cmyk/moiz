-- OWNER REVIEW REQUIRED. NOT APPLIED.
-- Additive setup: existing products, orders, users and storage are untouched.
-- Run once only after backup/schema review; any name collision aborts the transaction.
BEGIN;
CREATE FUNCTION public.mb_is_admin() RETURNS boolean LANGUAGE sql STABLE SET search_path = '' AS $$ SELECT COALESCE(auth.jwt()->'app_metadata'->>'role','') = 'super_admin' $$;
CREATE TABLE public.mb_shops (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), owner_id uuid UNIQUE NOT NULL REFERENCES auth.users(id),
 owner_name text NOT NULL CHECK(length(owner_name) BETWEEN 2 AND 180), email text NOT NULL,
 phone text NOT NULL, name text NOT NULL CHECK(length(name) BETWEEN 2 AND 180), slug text UNIQUE NOT NULL,
 category text NOT NULL, city text NOT NULL, area text NOT NULL, address text NOT NULL, return_address text NOT NULL,
 description text NOT NULL CHECK(length(description) BETWEEN 20 AND 1000),
 status text NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','approved','rejected','needs_information','suspended')),
 reason text NOT NULL DEFAULT '', verified boolean NOT NULL DEFAULT false,
 plan text NOT NULL DEFAULT 'free' CHECK(plan IN ('free','business','premium')),
 created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now(), reviewed_at timestamptz
);
ALTER TABLE public.mb_shops ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.mb_shops FROM anon,authenticated;
GRANT SELECT ON public.mb_shops TO authenticated;
CREATE POLICY mb_shops_private_read ON public.mb_shops FOR SELECT TO authenticated USING(owner_id=auth.uid() OR public.mb_is_admin());
CREATE VIEW public.mb_public_shops WITH (security_barrier=true) AS SELECT id,name,slug,category,city,description,verified,created_at FROM public.mb_shops WHERE status='approved';
GRANT SELECT ON public.mb_public_shops TO anon,authenticated;
CREATE TABLE public.mb_admin_events(id uuid PRIMARY KEY DEFAULT gen_random_uuid(),actor_id uuid NOT NULL REFERENCES auth.users(id),shop_id uuid NOT NULL REFERENCES public.mb_shops(id),action text NOT NULL,reason text NOT NULL DEFAULT '',created_at timestamptz DEFAULT now());
ALTER TABLE public.mb_admin_events ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.mb_admin_events FROM anon,authenticated;
GRANT SELECT ON public.mb_admin_events TO authenticated;
CREATE POLICY mb_admin_events_read ON public.mb_admin_events FOR SELECT TO authenticated USING(public.mb_is_admin());
CREATE FUNCTION public.mb_submit_shop(details jsonb) RETURNS public.mb_shops LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE s public.mb_shops; uid uuid:=auth.uid(); mail text; slug_base text; slug_value text;
BEGIN
 IF uid IS NULL THEN RAISE EXCEPTION 'Sign in required'; END IF;
 SELECT email INTO mail FROM auth.users WHERE id=uid;
 IF mail IS NULL OR details->>'email' IS DISTINCT FROM mail OR details->>'acceptedTerms' IS DISTINCT FROM 'true' THEN RAISE EXCEPTION 'Invalid account or terms'; END IF;
 IF length(trim(details->>'owner')) NOT BETWEEN 2 AND 180 OR length(trim(details->>'name')) NOT BETWEEN 2 AND 180 OR length(trim(details->>'description')) NOT BETWEEN 20 AND 1000 OR coalesce(length(details->>'address'),0)<2 OR coalesce(length(details->>'category'),0)<2 OR coalesce(length(details->>'city'),0)<2 OR coalesce(length(details->>'area'),0)<2 OR coalesce(details->>'phone','') !~ '^(\+92|92|0)3[0-9]{9}$' THEN RAISE EXCEPTION 'Invalid shop details'; END IF;
 PERFORM pg_advisory_xact_lock(hashtextextended(uid::text,0));
 SELECT * INTO s FROM public.mb_shops WHERE owner_id=uid FOR UPDATE;
 IF FOUND THEN
  IF s.status NOT IN ('rejected','needs_information') THEN RAISE EXCEPTION 'This shop cannot be resubmitted'; END IF;
  UPDATE public.mb_shops SET owner_name=trim(details->>'owner'),phone=details->>'phone',name=trim(details->>'name'),category=details->>'category',city=details->>'city',area=details->>'area',address=details->>'address',return_address=CASE WHEN details->>'sameReturn'='true' THEN details->>'address' ELSE coalesce(details->>'returnAddress','') END,description=details->>'description',status='pending',reason='',verified=false,updated_at=now() WHERE id=s.id RETURNING * INTO s;
 ELSE
  slug_base:=trim(both '-' FROM regexp_replace(lower(details->>'name'),'[^a-z0-9]+','-','g'));
  IF slug_base='' THEN slug_base:='shop'; END IF;
  slug_value:=left(slug_base,60);
  PERFORM pg_advisory_xact_lock(hashtextextended(slug_value,2));
  IF EXISTS(SELECT 1 FROM public.mb_shops WHERE slug=slug_value) THEN slug_value:=left(slug_base,60)||'-'||replace(uid::text,'-',''); END IF;
  INSERT INTO public.mb_shops(owner_id,owner_name,email,phone,name,slug,category,city,area,address,return_address,description)
  VALUES(uid,trim(details->>'owner'),mail,details->>'phone',trim(details->>'name'),slug_value,details->>'category',details->>'city',details->>'area',details->>'address',CASE WHEN details->>'sameReturn'='true' THEN details->>'address' ELSE coalesce(details->>'returnAddress','') END,details->>'description') RETURNING * INTO s;
 END IF;
 RETURN s;
END $$;
CREATE FUNCTION public.mb_review_shop(shop_id uuid,decision text,review_reason text,mark_verified boolean DEFAULT false) RETURNS public.mb_shops LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE s public.mb_shops;
BEGIN
 IF NOT public.mb_is_admin() THEN RAISE EXCEPTION 'Owner access required'; END IF;
 IF decision NOT IN ('approved','rejected','needs_information','suspended') OR (decision<>'approved' AND length(trim(coalesce(review_reason,'')))<5) THEN RAISE EXCEPTION 'Invalid review decision'; END IF;
 UPDATE public.mb_shops SET status=decision,reason=left(coalesce(review_reason,''),1000),verified=(decision='approved' AND mark_verified),reviewed_at=now(),updated_at=now() WHERE id=shop_id RETURNING * INTO s;
 IF NOT FOUND THEN RAISE EXCEPTION 'Shop not found'; END IF;
 INSERT INTO public.mb_admin_events(actor_id,shop_id,action,reason) VALUES(auth.uid(),shop_id,decision,coalesce(review_reason,''));
 RETURN s;
END $$;
REVOKE ALL ON FUNCTION public.mb_submit_shop(jsonb) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.mb_review_shop(uuid,text,text,boolean) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mb_submit_shop(jsonb) TO authenticated;
GRANT EXECUTE ON FUNCTION public.mb_review_shop(uuid,text,text,boolean) TO authenticated;
-- Plans prepared without billing, payment collection or automatic subscriptions.
CREATE TABLE public.mb_plans(code text PRIMARY KEY,name text NOT NULL,price_pkr numeric NOT NULL CHECK(price_pkr>=0),enabled boolean NOT NULL DEFAULT false,billing_period text,product_limit integer CHECK(product_limit>0));
INSERT INTO public.mb_plans(code,name,price_pkr,enabled) VALUES('free','Free',0,true),('business','Business',1500,false),('premium','Premium',3000,false);
ALTER TABLE public.mb_plans ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.mb_plans FROM anon,authenticated;
GRANT SELECT ON public.mb_plans TO anon,authenticated;
CREATE POLICY mb_plans_read ON public.mb_plans FOR SELECT USING(true);
COMMIT;
