import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import {defineConfig} from 'vite';

export default defineConfig(() => {
  const rawUrl = (process.env.NEXT_PUBLIC_SUPABASE_URL || process.env.VITE_SUPABASE_URL || '').trim();
  const match = rawUrl.match(/https:\/\/[a-zA-Z0-9-]+\.supabase\.co/);
  const cleanUrl = match ? match[0] : rawUrl.replace(/\/rest\/v1\/?$/, '').replace(/\/$/, '');
  const cleanKey = (process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || process.env.VITE_SUPABASE_ANON_KEY || '').trim();

  return {
    plugins: [react(), tailwindcss()],
    define: {
      'process.env.NEXT_PUBLIC_SUPABASE_URL': JSON.stringify(cleanUrl),
      'process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY': JSON.stringify(cleanKey),
      'process.env.VITE_SUPABASE_URL': JSON.stringify(cleanUrl),
      'process.env.VITE_SUPABASE_ANON_KEY': JSON.stringify(cleanKey),
      'process.env.NEXT_PUBLIC_MARKETPLACE_ENABLED': JSON.stringify('true'),
      'process.env.APP_URL': JSON.stringify(process.env.APP_URL || ''),
      'process.env': JSON.stringify({
        NEXT_PUBLIC_SUPABASE_URL: cleanUrl,
        NEXT_PUBLIC_SUPABASE_ANON_KEY: cleanKey,
        VITE_SUPABASE_URL: cleanUrl,
        VITE_SUPABASE_ANON_KEY: cleanKey,
        NEXT_PUBLIC_MARKETPLACE_ENABLED: 'true',
        APP_URL: process.env.APP_URL || '',
      }),
    },
    resolve: {
      alias: {
        '@': path.resolve(__dirname, './src'),
        'next/link': path.resolve(__dirname, './src/router/link.tsx'),
        'next/image': path.resolve(__dirname, './src/router/image.tsx'),
        'next/navigation': path.resolve(__dirname, './src/router/navigation.ts'),
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modify—file watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
