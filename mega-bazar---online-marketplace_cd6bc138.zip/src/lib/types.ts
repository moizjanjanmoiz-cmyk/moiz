export interface Product {
  id: string;
  name: string;
  slug: string;
  sku: string;
  category: string;
  subcategory?: string;
  brand: string;
  description: string;
  shortDescription?: string;
  price: number; // In PKR
  originalPrice: number; // In PKR
  discountPercentage: number;
  stock: number;
  lowStockThreshold: number;
  images: string[];
  specifications: Record<string, string>;
  tags: string[];
  isFeatured: boolean;
  isBestSeller: boolean;
  isFlashDeal: boolean;
  rating: number;
  reviewCount: number;
  status: 'active' | 'draft' | 'archived';
  seoTitle?: string;
  metaDescription?: string;
  imageAltText?: string;
  whatsappNumber?: string;
  sellerWhatsapp?: string;
  size?: string;
  sizes?: string[];
  attributes?: Record<string, string>;
  createdAt: string;
  updatedAt: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  description: string;
  image: string;
  icon?: string;
  count: number;
  status: 'active' | 'inactive';
  displayOrder: number;
}

export interface CartItem {
  productId: string;
  product: Product;
  quantity: number;
  selectedSize?: string;
}

export interface Address {
  id?: string;
  fullName: string;
  phone: string;
  address: string;
  city: string;
  province: string;
  postalCode: string;
  country: string;
  isDefault?: boolean;
}

export type OrderStatus =
  | 'Pending'
  | 'Confirmed'
  | 'Processing'
  | 'Shipped'
  | 'Out for Delivery'
  | 'Delivered'
  | 'Cancelled'
  | 'Refunded';

export type PaymentMethod =
  | 'cod'
  | 'easypaisa'
  | 'jazzcash'
  | 'card'
  | 'online';

export type PaymentStatus =
  | 'pending'
  | 'verified'
  | 'paid'
  | 'failed'
  | 'refunded';

export type DeliveryMethod = 'standard' | 'express';

export interface OrderItem {
  productId: string;
  name: string;
  image: string;
  price: number;
  originalPrice?: number;
  quantity: number;
  selectedSize?: string;
  sku?: string;
}

export interface Order {
  id: string;
  orderNumber: string;
  customerId: string;
  customerName: string;
  email: string;
  phone: string;
  shippingAddress: Address;
  items: OrderItem[];
  quantities: number;
  subtotal: number;
  discount: number;
  couponCode?: string;
  shippingFee: number;
  deliveryMethod: 'standard' | 'express';
  tax: number;
  grandTotal: number;
  currency: string;
  paymentMethod: PaymentMethod;
  paymentStatus: PaymentStatus;
  transactionId?: string;
  paymentProofUrl?: string;
  orderStatus: OrderStatus;
  trackingNumber?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Coupon {
  id: string;
  code: string;
  discountType: 'percentage' | 'fixed';
  value: number;
  minOrder: number;
  maxDiscount?: number;
  expiryDate: string;
  usageLimit: number;
  usageCount: number;
  status: 'active' | 'inactive';
}

export interface Banner {
  id: string;
  title: string;
  subtitle: string;
  tag?: string;
  discountText?: string;
  imageUrl: string;
  buttonText: string;
  link: string;
  type: 'hero' | 'promo' | 'sale';
  status: 'active' | 'inactive';
  displayOrder: number;
}

export interface Review {
  id: string;
  productId: string;
  productName: string;
  customerId: string;
  customerName: string;
  customerEmail?: string;
  rating: number;
  comment: string;
  isVerifiedPurchase: boolean;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: string;
}

export interface StoreSettings {
  storeName: string;
  tagline: string;
  description: string;
  currency: string;
  currencySymbol: string;
  whatsappNumber: string;
  contactEmail: string;
  freeShippingThreshold: number;
  standardShippingFee: number;
  expressShippingFee: number;
  easypaisaAccountName: string;
  easypaisaAccountNumber: string;
  jazzcashAccountName: string;
  jazzcashTillId: string;
  taxPercentage: number;
  adminEmail?: string;
  adminUsername?: string;
  adminPassword?: string;
}

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  phone?: string;
  role: 'customer' | 'admin' | 'super_admin' | 'seller';
  addresses: Address[];
  createdAt: string;
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  type: 'order' | 'promo' | 'inventory' | 'review' | 'system';
  read: boolean;
  createdAt: string;
  link?: string;
}

export type ShopStatus = 'Pending' | 'Approved' | 'Rejected' | 'Suspended';

export interface SellerShop {
  id: string;
  ownerId: string;
  ownerName: string;
  email: string;
  phone: string;
  name: string;
  slug: string;
  category: string;
  city: string;
  address: string;
  logoUrl?: string;
  description?: string;
  status: ShopStatus;
  rejectionReason?: string;
  isVerified: boolean;
  commissionRate: string;
  createdAt: string;
  updatedAt: string;
}

export interface Complaint {
  id: string;
  ticketNumber: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  shopName?: string;
  orderNumber?: string;
  subject: string;
  description: string;
  status: 'Open' | 'Investigating' | 'Resolved' | 'Dismissed';
  priority: 'low' | 'medium' | 'high';
  createdAt: string;
  resolutionNotes?: string;
}
