import { createClient } from '@supabase/supabase-js';

const FALLBACK_URL = 'https://preview.invalid';
const FALLBACK_KEY = 'preview-only-key';

function getEnvVar(name: string): string | undefined {
  if (typeof import.meta !== 'undefined' && import.meta.env && import.meta.env[name]) {
    const val = String(import.meta.env[name]).trim();
    if (val && !val.includes('MY_') && val !== 'undefined') return val;
  }
  if (typeof process !== 'undefined' && process.env && process.env[name]) {
    const val = String(process.env[name]).trim();
    if (val && !val.includes('MY_') && val !== 'undefined') return val;
  }
  return undefined;
}

function sanitizeUrl(raw: string | undefined): string | null {
  if (!raw) return null;
  const trimmed = raw.trim();
  const match = trimmed.match(/https:\/\/[a-zA-Z0-9-]+\.supabase\.co/);
  if (match) {
    return match[0];
  }
  if (trimmed.startsWith('https://') || trimmed.startsWith('http://')) {
    if (!trimmed.includes('invalid') && !trimmed.includes('example')) {
      return trimmed.replace(/\/rest\/v1\/?$/, '').replace(/\/$/, '');
    }
  }
  return null;
}

const envUrl = sanitizeUrl(getEnvVar('VITE_SUPABASE_URL') || getEnvVar('NEXT_PUBLIC_SUPABASE_URL'));
const envKey = getEnvVar('VITE_SUPABASE_ANON_KEY') || getEnvVar('NEXT_PUBLIC_SUPABASE_ANON_KEY');

const storedUrl = typeof window !== 'undefined' ? sanitizeUrl(localStorage.getItem('mb_supabase_url') || undefined) : null;
const storedKey = typeof window !== 'undefined' ? (localStorage.getItem('mb_supabase_anon_key') || undefined) : undefined;

const effectiveUrl = envUrl || storedUrl;
const effectiveKey = envKey || storedKey;

export const isSupabaseConfigured = Boolean(effectiveUrl && effectiveKey && effectiveUrl !== FALLBACK_URL);

export const supabaseUrl = effectiveUrl || FALLBACK_URL;
export const supabaseAnonKey = effectiveKey || FALLBACK_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
    storage: typeof window !== 'undefined' ? window.localStorage : undefined,
  },
});
