import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatCurrency(amount: number, currency: string = 'PKR'): string {
  if (isNaN(amount)) return `${currency} 0`;
  return `${currency} ${Math.round(amount).toLocaleString('en-US')}`;
}

export function formatDate(dateString: string): string {
  try {
    const d = new Date(dateString);
    return d.toLocaleDateString('en-PK', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return dateString;
  }
}

export function generateOrderNumber(): string {
  const rand = Math.floor(1000 + Math.random() * 9000);
  return `MB-${rand}`;
}

export function isValidEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

export function calculateDiscount(originalPrice: number, currentPrice: number): number {
  if (!originalPrice || originalPrice <= currentPrice) return 0;
  return Math.round(((originalPrice - currentPrice) / originalPrice) * 100);
}

export async function downloadImage(url: string, filename: string = 'product-image.jpg') {
  if (!url) return;

  // Direct download for base64 data URLs and blob URLs
  if (url.startsWith('data:') || url.startsWith('blob:')) {
    const link = document.createElement('a');
    link.href = url;
    let finalName = filename;
    if (url.startsWith('data:image/png') && !finalName.endsWith('.png')) {
      finalName = finalName.replace(/\.[^/.]+$/, '') + '.png';
    } else if (url.startsWith('data:image/webp') && !finalName.endsWith('.webp')) {
      finalName = finalName.replace(/\.[^/.]+$/, '') + '.webp';
    } else if ((url.startsWith('data:image/jpeg') || url.startsWith('data:image/jpg')) && !finalName.endsWith('.jpg') && !finalName.endsWith('.jpeg')) {
      finalName = finalName.replace(/\.[^/.]+$/, '') + '.jpg';
    }
    link.download = finalName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    return;
  }

  try {
    const res = await fetch(url);
    if (!res.ok) throw new Error('Failed to fetch image blob');
    const blob = await res.blob();
    const blobUrl = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = blobUrl;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setTimeout(() => URL.revokeObjectURL(blobUrl), 1500);
  } catch {
    // Direct anchor fallback
    const link = document.createElement('a');
    link.href = url;
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
}

export function downloadProductsCSV(products: any[], filename: string = 'mega-bazar-products.csv') {
  if (!products || products.length === 0) return;

  const headers = [
    'ID',
    'Product Name',
    'SKU',
    'Category',
    'Brand',
    'Price (PKR)',
    'Compare Price (PKR)',
    'Stock Quantity',
    'In Stock',
    'Rating',
    'Review Count',
    'Is Featured',
    'Tags',
    'Image URL',
    'Description',
  ];

  const escapeCSV = (str: any) => {
    if (str === null || str === undefined) return '""';
    const s = String(str).replace(/"/g, '""');
    return `"${s}"`;
  };

  const rows = products.map((p) => [
    escapeCSV(p.id),
    escapeCSV(p.name),
    escapeCSV(p.sku),
    escapeCSV(p.category),
    escapeCSV(p.brand),
    escapeCSV(p.price),
    escapeCSV(p.comparePrice || ''),
    escapeCSV(p.stock),
    escapeCSV(p.inStock ? 'Yes' : 'No'),
    escapeCSV(p.rating),
    escapeCSV(p.reviewCount || 0),
    escapeCSV(p.isFeatured ? 'Yes' : 'No'),
    escapeCSV(Array.isArray(p.tags) ? p.tags.join(', ') : ''),
    escapeCSV(p.image),
    escapeCSV(p.description),
  ]);

  const csvContent = '\uFEFF' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\r\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export function downloadProductsJSON(products: any[], filename: string = 'mega-bazar-products.json') {
  if (!products || products.length === 0) return;
  const jsonContent = JSON.stringify(products, null, 2);
  const blob = new Blob([jsonContent], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export {
  formatPakistaniWhatsAppNumber,
  autoNormalizeWhatsAppInput,
  createWhatsAppLink,
  formatDisplayPakistaniPhone,
  type WhatsAppValidationResult,
} from './whatsapp';

export function generateShopSlug(name: string): string {
  const base = (name || '')
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
  return base || `shop-${Date.now().toString(36)}`;
}


