export const SELLER_DRAFT_KEY = 'megabazar-seller-draft-v1';
export type SellerDraft = { owner: string; email: string; phone: string; name: string; category: string; type: string; city: string; area: string; address: string; sameReturn: boolean; returnAddress: string; dispatchDays: string; description: string; terms: boolean };
export const emptySellerDraft: SellerDraft = { owner: '', email: '', phone: '', name: '', category: '', type: 'individual', city: '', area: '', address: '', sameReturn: true, returnAddress: '', dispatchDays: '2', description: '', terms: false };
export function readSellerDraft(): SellerDraft {
  try { const raw = JSON.parse(localStorage.getItem(SELLER_DRAFT_KEY) || 'null'); if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return emptySellerDraft; const next = { ...emptySellerDraft }; for (const key of Object.keys(next) as (keyof SellerDraft)[]) { if (typeof raw[key] === typeof next[key]) Object.assign(next, { [key]: raw[key] }); } return next; } catch { return emptySellerDraft; }
}
export function shopSlug(name: string) { return name.toLowerCase().normalize('NFKD').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 60) || 'your-shop'; }
