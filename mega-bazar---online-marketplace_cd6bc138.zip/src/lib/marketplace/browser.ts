import { supabase, isSupabaseConfigured } from '@/lib/supabase/client';

export const marketplaceEnabled =
  isSupabaseConfigured ||
  (typeof import.meta !== 'undefined' &&
    (import.meta.env?.VITE_MARKETPLACE_ENABLED === 'true' ||
      import.meta.env?.NEXT_PUBLIC_MARKETPLACE_ENABLED === 'true')) ||
  (typeof process !== 'undefined' &&
    (process.env?.VITE_MARKETPLACE_ENABLED === 'true' ||
      process.env?.NEXT_PUBLIC_MARKETPLACE_ENABLED === 'true'));

export async function marketplaceFetch(path: string, options: RequestInit = {}) {
  const { data: { session } } = await supabase.auth.getSession();
  const headers = new Headers(options.headers);
  headers.set('Content-Type', 'application/json');
  if (session) headers.set('Authorization', `Bearer ${session.access_token}`);
  const response = await fetch(path, { ...options, headers, cache: 'no-store' });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || 'Request failed.');
  return data;
}
