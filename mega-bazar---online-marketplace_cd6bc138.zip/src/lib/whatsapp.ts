/**
 * Pakistani WhatsApp Number Formatting & Validation Utility
 *
 * Strict Rules:
 * 1. Automatically converts Pakistani mobile numbers into international format: `923XXXXXXXXX` (12 digits)
 * 2. `03001234567` (11 digits starting with 03) -> `923001234567`
 * 3. `+923001234567` -> `923001234567`
 * 4. `923001234567` -> `923001234567`
 * 5. Automatically strips spaces, hyphens (-), brackets (), plus signs (+), dots, slashes, and any non-digit characters.
 * 6. Always builds valid `https://wa.me/923XXXXXXXXX` links.
 * 7. Enforces strict validation: rejects incomplete, oversized, or non-Pakistani mobile prefixes.
 * 8. Ensures database and state consistency.
 */

export interface WhatsAppValidationResult {
  isValid: boolean;
  formatted: string;       // Normalized 12-digit international format: "923001234567"
  original: string;        // Original raw user input
  cleanDigits: string;     // Digits only
  error?: string;          // Clear error description in Urdu & English
  waLink: string;          // https://wa.me/923001234567
  display: string;         // Pretty display format: "+92 300 1234567"
}

/**
 * Normalizes any Arabic or Urdu numeral characters (e.g. ۰۱۲۳۴۵۶۷۸۹ or ٠١٢٣٤٥٦٧٨٩) to standard ASCII digits 0-9.
 */
export function normalizeEasternNumerals(input: string): string {
  const urduDigits = '۰۱۲۳۴۵۶۷۸۹';
  const arabicDigits = '٠١٢٣٤٥٦٧٨٩';
  return input.replace(/[\u0660-\u0669\u06F0-\u06F9]/g, (char) => {
    const uIdx = urduDigits.indexOf(char);
    if (uIdx !== -1) return uIdx.toString();
    const aIdx = arabicDigits.indexOf(char);
    if (aIdx !== -1) return aIdx.toString();
    return char;
  });
}

/**
 * Validates and formats a Pakistani WhatsApp number according to strict international rules.
 * 
 * Rules:
 * - 03001234567 -> 923001234567
 * - +923001234567 -> 923001234567
 * - 923001234567 -> 923001234567
 * - Strips all spaces, hyphens, brackets, dots, commas, plus signs
 * - Rejects incomplete numbers (< 11 digits) or oversized numbers (> 12 digits)
 * - Rejects non-mobile networks (must start with 03 / 923)
 * 
 * @param input - The raw phone number input by seller or user.
 * @param isRequired - If true, an empty string is treated as invalid.
 * @returns WhatsAppValidationResult object
 */
export function formatPakistaniWhatsAppNumber(
  input: string | undefined | null,
  isRequired: boolean = false
): WhatsAppValidationResult {
  const original = (input ?? '').trim();

  // If input is empty
  if (!original) {
    if (isRequired) {
      return {
        isValid: false,
        formatted: '',
        original: '',
        cleanDigits: '',
        error: 'WhatsApp number is required',
        waLink: '',
        display: '',
      };
    }
    return {
      isValid: true,
      formatted: '',
      original: '',
      cleanDigits: '',
      waLink: '',
      display: '',
    };
  }

  // 1. Convert any numeral characters to standard digits
  const normalizedText = normalizeEasternNumerals(original);

  // 2. Remove all spaces, hyphens, brackets, pluses, dots, and non-digit characters
  const cleanDigits = normalizedText.replace(/\D/g, '');

  if (!cleanDigits) {
    return {
      isValid: false,
      formatted: '',
      original,
      cleanDigits: '',
      error: 'Only valid numeric digits are allowed',
      waLink: '',
      display: '',
    };
  }

  let formatted = cleanDigits;

  // 3. Handle all common Pakistani mobile prefix patterns:
  // e.g. 009203001234567 -> 923001234567
  if (formatted.startsWith('009203')) {
    formatted = '923' + formatted.slice(6);
  }
  // e.g. 00923001234567 -> 923001234567
  else if (formatted.startsWith('0092')) {
    formatted = '92' + formatted.slice(4);
  }
  // e.g. +92 0300 1234567 -> 9203001234567 -> 923001234567
  else if (formatted.startsWith('9203')) {
    formatted = '923' + formatted.slice(4);
  }
  // e.g. 03001234567 (11 digits starting with 03) -> 923001234567
  else if (formatted.startsWith('03')) {
    formatted = '92' + formatted.slice(1);
  }
  // e.g. 3001234567 (10 digits starting with 3) -> 923001234567
  else if (formatted.startsWith('3') && formatted.length === 10) {
    formatted = '92' + formatted;
  }
  // e.g. 923001234567 (already 12-digit international format with country code 92)

  // 4. Strict Pakistani Mobile Network Validation:
  // Must be exactly 12 digits: Country Code 92 + Mobile prefix 3XX + 7 subscriber digits
  // Mobile prefixes: 30X, 31X, 32X, 33X, 34X, 35X, 36X, 37X (Jazz, Zong, Telenor, Ufone, SCOM, Onic)
  const pakMobileRegex = /^923\d{9}$/;

  if (!pakMobileRegex.test(formatted)) {
    let errorMsg = 'Please enter a valid Pakistan WhatsApp number (e.g., 03001234567 or 923001234567)';

    if (formatted.length < 12) {
      errorMsg = 'WhatsApp number is incomplete! Please enter an 11-digit mobile number (e.g., 03001234567)';
    } else if (formatted.length > 12) {
      errorMsg = 'WhatsApp number contains too many digits! Please enter an 11-digit mobile number (e.g., 03001234567)';
    } else if (!formatted.startsWith('923')) {
      errorMsg = 'Only Pakistan mobile numbers starting with 03 are accepted (e.g., 0300, 0318, 0345, 0321)';
    }

    return {
      isValid: false,
      formatted: '',
      original,
      cleanDigits,
      error: errorMsg,
      waLink: '',
      display: original,
    };
  }

  // 5. Build safe wa.me link and pretty human display
  const waLink = `https://wa.me/${formatted}`;
  const display = `+92 ${formatted.slice(2, 5)} ${formatted.slice(5)}`;

  return {
    isValid: true,
    formatted,
    original,
    cleanDigits,
    waLink,
    display,
  };
}

/**
 * Automatically converts user input to international format `923XXXXXXXXX`
 * if it represents a complete number or contains formatting symbols (spaces, hyphens, brackets, +).
 */
export function autoNormalizeWhatsAppInput(val: string): string {
  if (!val || !val.trim()) return '';
  const result = formatPakistaniWhatsAppNumber(val, false);
  if (!result.isValid || !result.formatted) return val;

  const normalized = normalizeEasternNumerals(val);
  const clean = normalized.replace(/\D/g, '');
  const hasFormatting = /[\s\-\(\)\+\.]/.test(normalized);

  // If the user has typed/pasted a complete Pakistani number or formatted text
  const isComplete =
    (clean.startsWith('03') && clean.length === 11) ||
    (clean.startsWith('923') && clean.length === 12) ||
    (clean.startsWith('00923') && clean.length === 14) ||
    (clean.startsWith('0092') && clean.length >= 13) ||
    (clean.startsWith('3') && clean.length === 10) ||
    (clean.startsWith('9203') && clean.length === 13) ||
    hasFormatting;

  if (isComplete) {
    return result.formatted;
  }
  return val;
}

/**
 * Creates a standard, reliable WhatsApp deep link (wa.me) with pre-filled message text.
 * Always resolves to a clean international number (`923XXXXXXXXX`).
 */
export function createWhatsAppLink(
  phone: string | undefined | null,
  message?: string,
  fallbackPhone: string = '923001234567'
): string {
  const result = formatPakistaniWhatsAppNumber(phone);
  let targetNumber = result.isValid && result.formatted ? result.formatted : '';

  if (!targetNumber) {
    const fallbackResult = formatPakistaniWhatsAppNumber(fallbackPhone);
    targetNumber = fallbackResult.isValid && fallbackResult.formatted ? fallbackResult.formatted : '923001234567';
  }

  if (!message) {
    return `https://wa.me/${targetNumber}`;
  }

  return `https://wa.me/${targetNumber}?text=${encodeURIComponent(message)}`;
}

/**
 * Formats a WhatsApp number for clean Pakistani display: +92 3XX XXXXXXX or 03XX-XXXXXXX
 */
export function formatDisplayPakistaniPhone(phone: string | undefined | null): string {
  const result = formatPakistaniWhatsAppNumber(phone);
  if (result.isValid && result.formatted) {
    return result.display;
  }
  return phone || '';
}
