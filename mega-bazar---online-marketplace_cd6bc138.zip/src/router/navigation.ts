import { useRouterContext } from './router-context';

export function useRouter() {
  const { navigate } = useRouterContext();
  return {
    push: (url: string) => navigate(url),
    replace: (url: string) => navigate(url),
    back: () => {
      if (typeof window !== 'undefined') window.history.back();
    },
    forward: () => {
      if (typeof window !== 'undefined') window.history.forward();
    },
    refresh: () => {
      if (typeof window !== 'undefined') window.location.reload();
    },
    prefetch: () => {},
  };
}

export function usePathname() {
  const { pathname } = useRouterContext();
  return pathname;
}

export function useSearchParams() {
  const { searchParams } = useRouterContext();
  return searchParams;
}

export function useParams<T extends Record<string, string | string[]>>(): T {
  const { pathname } = useRouterContext();
  // Extract simple dynamic route params e.g. /product/123 -> { id: '123' }, /demo-shops/slug -> { slug: 'slug' }
  const segments = pathname.split('/').filter(Boolean);
  const params: Record<string, string> = {};

  if (segments[0] === 'product' && segments[1]) {
    params.id = segments[1];
  } else if (segments[0] === 'demo-shops' && segments[1]) {
    params.slug = segments[1];
  } else if (segments[0] === 'category' && segments[1]) {
    params.slug = segments[1];
  } else if (segments[0] === 'order-confirmation' && segments[1]) {
    params.id = segments[1];
  } else if (segments[0] === 'shop' && segments[1]) {
    params.slug = segments[1];
  }

  return params as T;
}

export function notFound() {
  console.warn('Page or item not found');
}

export function redirect(url: string) {
  if (typeof window !== 'undefined') {
    window.location.href = url;
  }
}
