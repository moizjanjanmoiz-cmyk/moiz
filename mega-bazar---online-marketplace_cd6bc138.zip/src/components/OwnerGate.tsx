'use client';
import { useEffect,useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { supabase } from '@/lib/supabase/client';
import { marketplaceFetch,marketplaceEnabled } from '@/lib/marketplace/browser';
export function OwnerGate({children}:{children:React.ReactNode}){const router=useRouter();const [allowed,setAllowed]=useState(false),[error,setError]=useState('');useEffect(()=>{let active=true;if(!marketplaceEnabled){setError('Account setup is pending.');return;}const { data: listener }=supabase.auth.onAuthStateChange((event)=>{if(event==='SIGNED_OUT'){active=false;setAllowed(false);router.replace('/login');}});marketplaceFetch('/api/marketplace/me').then(async user=>{if(!user.isOwner){router.replace('/account');return;}try{await marketplaceFetch('/api/admin/auth',{method:'POST',body:'{}'});window.dispatchEvent(new Event('mb-owner-session'));}catch{}if(active)setAllowed(true);}).catch(()=>{if(active)router.replace('/login');});return()=>{active=false;listener.subscription.unsubscribe();};},[router]);if(!allowed)return <div className="max-w-md mx-auto p-8"><p role="status">{error||'Checking your account…'}</p>{error&&<Link href="/login" className="text-blue-600 underline mt-4 inline-block">Sign in</Link>}</div>;return <>{children}</>}
