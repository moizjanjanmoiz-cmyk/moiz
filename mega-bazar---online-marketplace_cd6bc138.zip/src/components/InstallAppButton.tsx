'use client';
import { useEffect, useRef, useState } from 'react';
import { Download, X } from 'lucide-react';
type InstallEvent = Event & { prompt: () => Promise<void>; userChoice: Promise<{ outcome: string }> };
export function InstallAppButton() {
  const deferred = useRef<InstallEvent | null>(null);
  const [installed, setInstalled] = useState(true);
  const [help, setHelp] = useState(false);
  const [ios, setIos] = useState(false);
  useEffect(() => {
    const standalone = window.matchMedia('(display-mode: standalone)');
    const sync = () => setInstalled(standalone.matches || !!(navigator as Navigator & { standalone?: boolean }).standalone);
    sync(); setIos(/iPad|iPhone|iPod/.test(navigator.userAgent));
    const capture = (e: Event) => { e.preventDefault(); deferred.current = e as InstallEvent; };
    const done = () => { deferred.current = null; setInstalled(true); setHelp(false); };
    window.addEventListener('beforeinstallprompt', capture);
    window.addEventListener('appinstalled', done);
    standalone.addEventListener('change', sync);
    if ('serviceWorker' in navigator && window.isSecureContext) navigator.serviceWorker.register('/sw.js').catch(() => {});
    return () => { window.removeEventListener('beforeinstallprompt', capture); window.removeEventListener('appinstalled', done); standalone.removeEventListener('change', sync); };
  }, []);
  async function install() {
    const event = deferred.current;
    if (!event) { setHelp(true); return; }
    deferred.current = null;
    try { await event.prompt(); await event.userChoice; } catch { setHelp(true); }
  }
  return <>
    {!installed && <button onClick={install} className="md:hidden inline-flex items-center gap-1.5 rounded-full border border-white/30 px-3 py-1.5 hover:bg-white/10"><Download size={14} /> Download App</button>}
    {help && <div className="fixed inset-0 z-[100] bg-slate-950/60 flex items-center justify-center p-5" onClick={() => setHelp(false)}><section role="dialog" aria-modal="true" aria-labelledby="install-title" className="relative w-full max-w-sm rounded-3xl bg-white p-7 text-slate-800 shadow-xl" onClick={e => e.stopPropagation()}><button autoFocus onClick={() => setHelp(false)} onKeyDown={e => { if (e.key === 'Escape') setHelp(false); }} aria-label="Close installation instructions" className="absolute right-4 top-4 p-2"><X size={18} /></button><Download className="text-blue-600 mb-4" /><h2 id="install-title" className="text-xl font-bold mb-3">Mega Bazar on your phone</h2><p className="text-sm leading-6 font-normal">{ios ? 'Open this website in Safari. Tap Share, then Add to Home Screen, and confirm Add.' : 'Open this website in Chrome. Tap the three-dot menu, then Install app or Add to Home screen. If installation is unavailable, please try again after browsing the site.'}</p><p className="mt-3 text-xs text-slate-500 font-normal">Installation requires a secure HTTPS website. Internet is needed for shopping and orders.</p><button onClick={() => setHelp(false)} className="mt-5 bg-blue-600 text-white rounded-xl px-5 py-2">Got it</button></section></div>}
  </>;
}
