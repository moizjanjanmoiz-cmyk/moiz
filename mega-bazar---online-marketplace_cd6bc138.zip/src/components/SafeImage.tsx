'use client';

import React, { useState } from 'react';
import Image, { ImageProps } from 'next/image';

interface SafeImageProps extends Omit<ImageProps, 'src' | 'onError'> {
  src?: string | null;
  fallbackSrc?: string;
  alt: string;
}

const DEFAULT_PRODUCT_FALLBACK =
  'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=800&q=80';

export function SafeImage({
  src,
  fallbackSrc = DEFAULT_PRODUCT_FALLBACK,
  alt,
  className,
  ...props
}: SafeImageProps) {
  const [errorSrc, setErrorSrc] = useState<string | null>(null);

  const cleanSrc = src && src.trim() !== '' ? src.trim() : fallbackSrc;
  const activeSrc = errorSrc === cleanSrc ? fallbackSrc : cleanSrc;

  const isLocalUpload = typeof activeSrc === 'string' && activeSrc.startsWith('/uploads/');
  const isDataOrBlob =
    typeof activeSrc === 'string' &&
    (activeSrc.startsWith('data:') || activeSrc.startsWith('blob:'));

  return (
    <Image
      {...props}
      src={activeSrc}
      alt={alt || 'Product Image'}
      className={className}
      onError={() => setErrorSrc(cleanSrc)}
      referrerPolicy="no-referrer"
      unoptimized={Boolean(isDataOrBlob || isLocalUpload)}
    />
  );
}

export default SafeImage;
