'use client';

import React from 'react';
import Link from 'next/link';
import Image from 'next/image';
import SafeImage from '@/components/SafeImage';
import { Product } from '@/lib/types';
import { useStore } from '@/context/StoreContext';
import { formatCurrency, calculateDiscount } from '@/lib/utils';
import { createWhatsAppLink, formatPakistaniWhatsAppNumber } from '@/lib/whatsapp';
import { Heart, ShoppingCart, Star, Eye, MessageCircle } from 'lucide-react';
import { motion } from 'motion/react';

interface ProductCardProps {
  product: Product;
  priority?: boolean;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, priority = false }) => {
  const { addToCart, toggleWishlist, isInWishlist, settings } = useStore();
  const inWishlist = isInWishlist(product.id);
  const discount = product.discountPercentage || calculateDiscount(product.originalPrice, product.price);

  const productSize =
    product.size ||
    product.attributes?.size ||
    product.specifications?.Size ||
    product.specifications?.size ||
    (product.sizes && product.sizes.length > 0 ? product.sizes[0] : undefined);

  const fallbackImage = 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=600&q=80';
  const [imageFailed, setImageFailed] = React.useState(false);
  const rawImage = product.images && product.images.length > 0 && product.images[0] ? product.images[0] : fallbackImage;
  const imageSrc = imageFailed ? fallbackImage : rawImage;

  const sellerPhone = product.whatsappNumber || product.sellerWhatsapp || '';
  const cardWhatsAppUrl = createWhatsAppLink(
    sellerPhone,
    `Product Link: ${typeof window !== "undefined" ? window.location.origin : "https://megabazar.pk"}/product/${product.id}\nHello! I would like to order this item on Mega Bazar:\n\n📦 *${product.name}*\n💰 *Price:* ${formatCurrency(product.price, settings.currency)}\n🔢 *SKU:* ${product.sku || product.id}\n\nPlease share delivery and cash on delivery details.`
  );

  return (
    <div className="group relative bg-white rounded-2xl border border-slate-100/80 shadow-xs hover:shadow-xl hover:border-blue-100 transition-all duration-300 flex flex-col overflow-hidden">
      {/* Product Image & Badges Container */}
      <div className="relative w-full aspect-square bg-slate-50 overflow-hidden">
        {/* Discount Badge */}
        {discount > 0 && (
          <span className="absolute top-2.5 left-2.5 z-10 px-2 py-1 bg-rose-500 text-white text-[11px] font-extrabold rounded-lg shadow-sm tracking-tight">
            -{discount}%
          </span>
        )}

        {/* Wishlist Heart Button */}
        <button
          onClick={(e) => {
            e.preventDefault();
            e.stopPropagation();
            toggleWishlist(product.id);
          }}
          suppressHydrationWarning
          className={`absolute top-2.5 right-2.5 z-10 w-8 h-8 rounded-full flex items-center justify-center transition-all duration-200 ${
            inWishlist
              ? 'bg-rose-50 text-rose-500 shadow-sm'
              : 'bg-white/80 backdrop-blur-xs text-slate-400 hover:text-rose-500 hover:bg-white shadow-xs'
          }`}
          aria-label={inWishlist ? 'Remove from Wishlist' : 'Add to Wishlist'}
        >
          <Heart className={`w-4 h-4 transition-transform active:scale-125 ${inWishlist ? 'fill-rose-500 text-rose-500' : ''}`} />
        </button>

        {/* Main Product Image */}
        <Link href={`/product/${product.id}`} className="block w-full h-full">
          <SafeImage
            src={rawImage}
            fallbackSrc={fallbackImage}
            alt={product.name}
            fill
            sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 25vw"
            priority={priority}
            className="object-cover object-center group-hover:scale-106 transition-transform duration-300"
          />
        </Link>

        {/* Quick View Overlay on Hover */}
        <div className="absolute inset-x-0 bottom-2.5 px-3 opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex justify-center gap-1.5 pointer-events-none group-hover:pointer-events-auto">
          <Link
            href={`/product/${product.id}`}
            className="px-3.5 py-1.5 bg-white/95 backdrop-blur-xs hover:bg-blue-600 text-slate-800 hover:text-white text-xs font-bold rounded-xl shadow-md flex items-center gap-1.5 transition-all"
          >
            <Eye className="w-3.5 h-3.5" /> View Details
          </Link>
        </div>
      </div>

      {/* Product Details */}
      <div className="p-3.5 sm:p-4 flex-1 flex flex-col justify-between">
        <div>
          {/* Category & Size */}
          <div className="flex items-center gap-1.5 flex-wrap mb-1">
            <span className="text-[11px] font-medium text-blue-600 uppercase tracking-wider">
              {product.category}
            </span>
            {productSize && (
              <span className="text-[10px] font-bold text-slate-700 bg-slate-100 px-1.5 py-0.5 rounded border border-slate-200">
                Size: {productSize}
              </span>
            )}
          </div>

          {/* Product Title */}
          <Link
            href={`/product/${product.id}`}
            className="text-xs sm:text-sm font-semibold text-slate-800 line-clamp-2 hover:text-blue-600 transition-colors leading-snug"
            title={product.name}
          >
            {product.name}
          </Link>

          {/* Rating & Reviews */}
          <div className="flex items-center gap-1.5 mt-1.5">
            <div className="flex text-amber-400">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  className={`w-3 h-3 ${
                    product.reviewCount > 0 && i < Math.floor(product.rating || 0)
                      ? 'fill-amber-400 text-amber-400'
                      : 'text-slate-200 fill-slate-200'
                  }`}
                />
              ))}
            </div>
            <span className="text-[11px] text-slate-400 font-medium">
              {product.reviewCount > 0 ? `${product.rating.toFixed(1)} (${product.reviewCount})` : 'No reviews yet'}
            </span>
          </div>
        </div>

        {/* Price & Add to Cart Action */}
        <div className="mt-3 pt-2.5 border-t border-slate-50 flex items-center justify-between gap-2">
          <div className="flex flex-col">
            <span className="text-sm sm:text-base font-bold text-slate-900 leading-none">
              {formatCurrency(product.price, settings.currency)}
            </span>
            {product.originalPrice > product.price && (
              <span className="text-[11px] text-slate-400 line-through mt-0.5">
                {formatCurrency(product.originalPrice, settings.currency)}
              </span>
            )}
          </div>

          <div className="flex items-center gap-1.5">
            {/* Direct WhatsApp Contact Button (Compact, Icon-only, Seller WhatsApp) */}
            {formatPakistaniWhatsAppNumber(sellerPhone).isValid && <a
              href={cardWhatsAppUrl}
              target="_blank"
              rel="noopener noreferrer"
              onClick={(e) => e.stopPropagation()}
              className="w-8 h-8 rounded-xl bg-emerald-50 hover:bg-[#25D366] text-[#25D366] hover:text-white flex items-center justify-center transition-all duration-200 shadow-2xs active:scale-95 group/wa"
              title="Chat / Order on WhatsApp"
              aria-label="Order on WhatsApp"
            >
              <MessageCircle className="w-4 h-4 fill-current transition-transform group-hover/wa:scale-110" />
            </a>}

            <button
              onClick={() => addToCart(product, 1, productSize)}
              disabled={product.stock <= 0}
              suppressHydrationWarning
              className={`w-8 h-8 rounded-xl flex items-center justify-center transition-all duration-200 shadow-2xs ${
                product.stock <= 0
                  ? 'bg-slate-100 text-slate-400 cursor-not-allowed'
                  : 'bg-blue-50 text-blue-600 hover:bg-blue-600 hover:text-white active:scale-95'
              }`}
              title={product.stock <= 0 ? 'Out of stock' : 'Add to cart'}
              aria-label="Add to cart"
            >
              <ShoppingCart className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
