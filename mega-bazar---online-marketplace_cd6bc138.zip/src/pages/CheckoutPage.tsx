import React, { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useStore } from '@/context/StoreContext';
import { formatCurrency, formatPakistaniWhatsAppNumber } from '@/lib/utils';
import { ShieldCheck, Truck, CheckCircle2, ArrowRight, ArrowLeft, CreditCard, Banknote, Smartphone, MapPin, Sparkles } from 'lucide-react';
import confetti from 'canvas-confetti';

const PAKISTAN_CITIES = [
  'Karachi',
  'Lahore',
  'Islamabad',
  'Rawalpindi',
  'Faisalabad',
  'Multan',
  'Peshawar',
  'Quetta',
  'Sialkot',
  'Gujranwala',
  'Hyderabad',
  'Abbottabad',
  'Bahawalpur',
  'Sargodha',
  'Sukkur',
  'Mardan',
  'Gujrat',
  'Larkana',
  'Mirpur (AJK)',
  'Muzaffarabad',
];

export const CheckoutPage: React.FC = () => {
  const router = useRouter();
  const { cart, cartSubtotal, cartDiscount, activeCoupon, settings, placeOrder, clearCart } = useStore();

  const [step, setStep] = useState<1 | 2>(1);

  // Form State
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('Karachi');
  const [postalCode, setPostalCode] = useState('');
  const [notes, setNotes] = useState('');

  // Shipping & Payment
  const [deliveryMethod, setDeliveryMethod] = useState<'standard' | 'express'>('standard');
  const [paymentMethod, setPaymentMethod] = useState<'cod' | 'easypaisa' | 'jazzcash' | 'card'>('cod');
  const [transactionId, setTransactionId] = useState('');

  // Errors & Loading
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const freeShippingThreshold = settings.freeShippingThreshold || 5000;
  const isFreeShipping = cartSubtotal >= freeShippingThreshold;
  const shippingFee = deliveryMethod === 'express' ? 500 : isFreeShipping ? 0 : (settings.standardShippingFee || 250);
  const grandTotal = Math.max(0, cartSubtotal - cartDiscount + shippingFee);

  const validateStep1 = () => {
    const errs: Record<string, string> = {};
    if (!fullName.trim()) errs.fullName = 'Full Name is required.';
    if (!address.trim()) errs.address = 'Complete delivery street address is required.';
    if (!phone.trim()) {
      errs.phone = 'Phone number is required.';
    } else {
      const phoneValidation = formatPakistaniWhatsAppNumber(phone);
      if (!phoneValidation.isValid) {
        errs.phone = 'Please enter a valid Pakistani mobile number (e.g. 03001234567).';
      }
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleNextStep = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateStep1()) {
      setStep(2);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handlePlaceOrder = async () => {
    if (isSubmitting) return;

    if (paymentMethod !== 'cod' && !transactionId.trim()) {
      setErrors({ transactionId: 'Please enter your Transfer Transaction ID (TID / Trx ID) for confirmation.' });
      return;
    }

    setIsSubmitting(true);

    try {
      const order = await placeOrder({
        customerName: fullName,
        email: email || 'customer@megabazar.pk',
        phone,
        shippingAddress: {
          fullName,
          phone,
          address,
          city,
          province: 'Pakistan',
          postalCode: postalCode || '75000',
          country: 'Pakistan',
        },
        items: cart.map((i) => ({
          productId: i.productId,
          name: i.product.name,
          image: i.product.images?.[0] || '',
          price: i.product.price,
          originalPrice: i.product.originalPrice,
          quantity: i.quantity,
          selectedSize: i.selectedSize,
          sku: i.product.sku,
        })),
        quantities: cart.reduce((s, i) => s + i.quantity, 0),
        subtotal: cartSubtotal,
        discount: cartDiscount,
        couponCode: activeCoupon?.code,
        shippingFee,
        deliveryMethod,
        tax: 0,
        grandTotal,
        currency: settings.currency || 'PKR',
        paymentMethod,
        paymentStatus: paymentMethod === 'cod' ? 'pending' : 'pending',
        transactionId: transactionId || undefined,
        orderStatus: 'Pending',
        notes: notes || undefined,
      });

      // Confetti celebration
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
        });
      } catch (err) {
        console.warn('Confetti error:', err);
      }

      clearCart();
      router.push(`/order-confirmation/${order.id}`);
    } catch (err) {
      console.error('Failed to create order:', err);
      alert('Unable to place order. Please review your details and try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (cart.length === 0) {
    return (
      <div className="max-w-xl mx-auto px-4 py-16 text-center">
        <h2 className="text-2xl font-black text-slate-800">Your cart is empty</h2>
        <p className="text-xs text-slate-500 mt-2">Add items to your cart before proceeding to checkout.</p>
        <Link href="/products" className="mt-5 inline-block px-6 py-3 bg-blue-600 text-white rounded-xl text-xs font-bold">
          Explore Products
        </Link>
      </div>
    );
  }

  return (
    <div className="py-8 sm:py-12 bg-slate-50 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        {/* Top Progress Header */}
        <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-200">
          <div>
            <nav className="flex items-center gap-2 text-xs text-slate-500 font-medium mb-1">
              <Link href="/cart" className="hover:text-blue-600 flex items-center gap-1">
                <ArrowLeft size={13} /> Back to Cart
              </Link>
            </nav>
            <h1 className="text-2xl sm:text-3xl font-black text-slate-900">Checkout & Order Placement</h1>
          </div>

          <div className="flex items-center gap-2 sm:gap-4 text-xs font-bold">
            <span className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full ${step === 1 ? 'bg-blue-600 text-white' : 'bg-emerald-50 text-emerald-700'}`}>
              <span className="w-4 h-4 rounded-full bg-white/20 text-center leading-4 text-[10px]">1</span> Address
            </span>
            <span className="text-slate-300">→</span>
            <span className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full ${step === 2 ? 'bg-blue-600 text-white' : 'bg-slate-200 text-slate-600'}`}>
              <span className="w-4 h-4 rounded-full bg-white/20 text-center leading-4 text-[10px]">2</span> Payment
            </span>
          </div>
        </div>

        <div className="grid lg:grid-cols-[1fr_380px] gap-8 items-start">
          {/* Main Form Box */}
          <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-xs space-y-6">
            {step === 1 ? (
              <form onSubmit={handleNextStep} className="space-y-6">
                <div>
                  <h2 className="text-lg font-black text-slate-900 flex items-center gap-2">
                    <MapPin size={20} className="text-blue-600" /> Shipping & Contact Details
                  </h2>
                  <p className="text-xs text-slate-500 mt-1">Please provide accurate Pakistani contact and delivery address.</p>
                </div>

                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="sm:col-span-2">
                    <label className="text-xs font-bold text-slate-700 block mb-1">Full Name *</label>
                    <input
                      type="text"
                      required
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      placeholder="e.g. Muhammad Moiz"
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:border-blue-500 outline-hidden"
                    />
                    {errors.fullName && <p className="text-[11px] text-rose-500 mt-1">{errors.fullName}</p>}
                  </div>

                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">Phone / WhatsApp Number *</label>
                    <input
                      type="text"
                      required
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="03182204441"
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:border-blue-500 outline-hidden"
                    />
                    {errors.phone && <p className="text-[11px] text-rose-500 mt-1">{errors.phone}</p>}
                    <p className="text-[10px] text-slate-400 mt-1">Rider will call or WhatsApp on this number before delivery.</p>
                  </div>

                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">Email Address (Optional)</label>
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="name@example.com"
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:border-blue-500 outline-hidden"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="text-xs font-bold text-slate-700 block mb-1">Street Address, House/Flat No, Area *</label>
                    <textarea
                      required
                      rows={2}
                      value={address}
                      onChange={(e) => setAddress(e.target.value)}
                      placeholder="House #, Street #, Sector/Block, Landmark, Area name"
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:border-blue-500 outline-hidden"
                    />
                    {errors.address && <p className="text-[11px] text-rose-500 mt-1">{errors.address}</p>}
                  </div>

                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">City *</label>
                    <select
                      value={city}
                      onChange={(e) => setCity(e.target.value)}
                      className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 outline-hidden"
                    >
                      {PAKISTAN_CITIES.map((c) => (
                        <option key={c} value={c}>{c}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">Postal Code (Optional)</label>
                    <input
                      type="text"
                      value={postalCode}
                      onChange={(e) => setPostalCode(e.target.value)}
                      placeholder="e.g. 75300"
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:border-blue-500 outline-hidden"
                    />
                  </div>
                </div>

                {/* Delivery Method Selection */}
                <div className="pt-4 border-t border-slate-100 space-y-3">
                  <h3 className="text-xs font-extrabold uppercase tracking-wider text-slate-900">Select Delivery Option</h3>
                  <div className="grid sm:grid-cols-2 gap-3">
                    <label
                      onClick={() => setDeliveryMethod('standard')}
                      className={`p-4 rounded-2xl border-2 cursor-pointer flex items-start gap-3 transition-all ${
                        deliveryMethod === 'standard' ? 'border-blue-600 bg-blue-50/50' : 'border-slate-200 hover:border-slate-300'
                      }`}
                    >
                      <input type="radio" name="delivery" checked={deliveryMethod === 'standard'} onChange={() => {}} className="mt-1 text-blue-600" />
                      <div>
                        <p className="font-bold text-xs text-slate-900">Standard Delivery (2-4 Days)</p>
                        <p className="text-[11px] text-slate-500 mt-0.5">Nationwide TCS / Leopards / Post</p>
                        <p className="text-xs font-black text-blue-600 mt-1">
                          {isFreeShipping ? 'FREE' : formatCurrency(settings.standardShippingFee || 250, settings.currency)}
                        </p>
                      </div>
                    </label>

                    <label
                      onClick={() => setDeliveryMethod('express')}
                      className={`p-4 rounded-2xl border-2 cursor-pointer flex items-start gap-3 transition-all ${
                        deliveryMethod === 'express' ? 'border-blue-600 bg-blue-50/50' : 'border-slate-200 hover:border-slate-300'
                      }`}
                    >
                      <input type="radio" name="delivery" checked={deliveryMethod === 'express'} onChange={() => {}} className="mt-1 text-blue-600" />
                      <div>
                        <p className="font-bold text-xs text-slate-900">Express Priority Air (1-2 Days)</p>
                        <p className="text-[11px] text-slate-500 mt-0.5">Urgent courier dispatch</p>
                        <p className="text-xs font-black text-blue-600 mt-1">{formatCurrency(500, settings.currency)}</p>
                      </div>
                    </label>
                  </div>
                </div>

                <div className="flex justify-end pt-4">
                  <button
                    type="submit"
                    className="px-8 py-3.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm rounded-xl flex items-center gap-2 shadow-md shadow-blue-500/25"
                  >
                    Continue to Payment <ArrowRight size={16} />
                  </button>
                </div>
              </form>
            ) : (
              /* Step 2: Payment Details */
              <div className="space-y-6">
                <div className="flex justify-between items-center pb-3 border-b border-slate-100">
                  <div>
                    <h2 className="text-lg font-black text-slate-900 flex items-center gap-2">
                      <Banknote size={20} className="text-blue-600" /> Choose Payment Method
                    </h2>
                    <p className="text-xs text-slate-500 mt-0.5">Select Cash on Delivery or Instant Mobile Wallet / Online Transfer.</p>
                  </div>
                  <button onClick={() => setStep(1)} className="text-xs font-bold text-blue-600 hover:underline">
                    Edit Address
                  </button>
                </div>

                {/* Delivery summary snippet */}
                <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200/80 text-xs text-slate-700 flex justify-between items-center">
                  <div>
                    <p className="font-bold">{fullName} · {phone}</p>
                    <p className="text-slate-500 truncate max-w-sm">{address}, {city}</p>
                  </div>
                  <span className="text-blue-600 font-bold uppercase tracking-wider text-[10px] bg-blue-50 px-2 py-1 rounded">
                    {deliveryMethod}
                  </span>
                </div>

                {/* Payment Options */}
                <div className="space-y-3">
                  {/* Option 1: Cash on Delivery (COD) */}
                  <label
                    onClick={() => setPaymentMethod('cod')}
                    className={`p-4 rounded-2xl border-2 cursor-pointer flex items-start gap-3 transition-all ${
                      paymentMethod === 'cod' ? 'border-emerald-600 bg-emerald-50/40' : 'border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <input type="radio" name="payment" checked={paymentMethod === 'cod'} onChange={() => {}} className="mt-1 text-emerald-600" />
                    <div>
                      <p className="font-extrabold text-xs text-slate-900 flex items-center gap-2">
                        Cash on Delivery (COD)
                        <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded">Most Popular</span>
                      </p>
                      <p className="text-[11px] text-slate-500 mt-1">Pay in cash directly to the delivery rider when your parcel arrives.</p>
                    </div>
                  </label>

                  {/* Option 2: EasyPaisa */}
                  <label
                    onClick={() => setPaymentMethod('easypaisa')}
                    className={`p-4 rounded-2xl border-2 cursor-pointer flex items-start gap-3 transition-all ${
                      paymentMethod === 'easypaisa' ? 'border-emerald-600 bg-emerald-50/40' : 'border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <input type="radio" name="payment" checked={paymentMethod === 'easypaisa'} onChange={() => {}} className="mt-1 text-emerald-600" />
                    <div className="w-full">
                      <div className="flex justify-between items-center">
                        <p className="font-extrabold text-xs text-slate-900">EasyPaisa Mobile Account</p>
                        <span className="text-[10px] font-bold text-emerald-600">Verified Title</span>
                      </div>
                      <div className="mt-2 p-3 bg-white rounded-xl border border-emerald-200 text-xs text-slate-800 space-y-1">
                        <p><strong>Account Title:</strong> {settings.easypaisaAccountName || 'Muhammad Moiz'}</p>
                        <p><strong>Account Number:</strong> {settings.easypaisaAccountNumber || '03182204441'}</p>
                      </div>
                    </div>
                  </label>

                  {/* Option 3: JazzCash */}
                  <label
                    onClick={() => setPaymentMethod('jazzcash')}
                    className={`p-4 rounded-2xl border-2 cursor-pointer flex items-start gap-3 transition-all ${
                      paymentMethod === 'jazzcash' ? 'border-amber-600 bg-amber-50/40' : 'border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <input type="radio" name="payment" checked={paymentMethod === 'jazzcash'} onChange={() => {}} className="mt-1 text-amber-600" />
                    <div className="w-full">
                      <div className="flex justify-between items-center">
                        <p className="font-extrabold text-xs text-slate-900">JazzCash Mobile Account</p>
                        <span className="text-[10px] font-bold text-amber-600">Instant Verification</span>
                      </div>
                      <div className="mt-2 p-3 bg-white rounded-xl border border-amber-200 text-xs text-slate-800 space-y-1">
                        <p><strong>Account Title:</strong> {settings.jazzcashAccountName || 'MOIZ.S'}</p>
                        <p><strong>Till ID / Number:</strong> {settings.jazzcashTillId || '984488781'}</p>
                      </div>
                    </div>
                  </label>

                  {/* Option 4: Debit / Credit Card */}
                  <label
                    onClick={() => setPaymentMethod('card')}
                    className={`p-4 rounded-2xl border-2 cursor-pointer flex items-start gap-3 transition-all ${
                      paymentMethod === 'card' ? 'border-blue-600 bg-blue-50/40' : 'border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <input type="radio" name="payment" checked={paymentMethod === 'card'} onChange={() => {}} className="mt-1 text-blue-600" />
                    <div>
                      <p className="font-extrabold text-xs text-slate-900">Visa / Mastercard / PayPak</p>
                      <p className="text-[11px] text-slate-500 mt-1">Direct card gateway with 256-bit bank encryption.</p>
                    </div>
                  </label>
                </div>

                {/* Transaction ID if wallet selected */}
                {(paymentMethod === 'easypaisa' || paymentMethod === 'jazzcash' || paymentMethod === 'card') && (
                  <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                    <label className="text-xs font-bold text-slate-800 block">
                      Transaction ID / Reference Number (TID) *
                    </label>
                    <input
                      type="text"
                      value={transactionId}
                      onChange={(e) => {
                        setTransactionId(e.target.value);
                        setErrors({});
                      }}
                      placeholder="e.g. TRX-982347102"
                      className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-xs font-mono focus:border-blue-500 outline-hidden"
                    />
                    {errors.transactionId && <p className="text-[11px] text-rose-500">{errors.transactionId}</p>}
                    <p className="text-[10px] text-slate-500">
                      Send {formatCurrency(grandTotal, settings.currency)} to the account details above and paste the confirmation SMS Transaction ID here.
                    </p>
                  </div>
                )}

                {/* Additional Delivery Notes */}
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Delivery Notes (Optional)</label>
                  <input
                    type="text"
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="e.g. Leave with security guard, call before arriving..."
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:border-blue-500 outline-hidden"
                  />
                </div>

                <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
                  <button
                    type="button"
                    onClick={() => setStep(1)}
                    className="px-5 py-2.5 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-xl"
                  >
                    Back to Address
                  </button>

                  <button
                    type="button"
                    onClick={handlePlaceOrder}
                    disabled={isSubmitting}
                    className="px-8 py-3.5 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-sm rounded-xl flex items-center gap-2 shadow-lg shadow-emerald-600/30 transition-all disabled:opacity-50"
                  >
                    {isSubmitting ? 'Placing Order...' : `Confirm & Place Order (${formatCurrency(grandTotal, settings.currency)})`}
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Right: Summary Box */}
          <div className="bg-white p-5 sm:p-6 rounded-3xl border border-slate-200 shadow-xs space-y-5 sticky top-24">
            <h3 className="text-sm font-black text-slate-900 pb-3 border-b border-slate-100">
              Items in Order ({cart.reduce((s, i) => s + i.quantity, 0)})
            </h3>

            <div className="space-y-3 max-h-64 overflow-y-auto pr-1">
              {cart.map((item) => (
                <div key={`${item.productId}-${item.selectedSize || 'default'}`} className="flex gap-3 items-center text-xs">
                  <img
                    src={item.product.images?.[0] || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=200&q=80'}
                    alt={item.product.name}
                    className="w-12 h-12 rounded-lg object-cover border border-slate-100 shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <p className="font-bold text-slate-800 truncate">{item.product.name}</p>
                    <p className="text-[11px] text-slate-400">Qty: {item.quantity} {item.selectedSize ? `· Size ${item.selectedSize}` : ''}</p>
                  </div>
                  <span className="font-extrabold text-slate-900">
                    {formatCurrency(item.product.price * item.quantity, settings.currency)}
                  </span>
                </div>
              ))}
            </div>

            <div className="space-y-2 pt-3 border-t border-slate-100 text-xs text-slate-600">
              <div className="flex justify-between">
                <span>Subtotal</span>
                <span className="font-bold text-slate-900">{formatCurrency(cartSubtotal, settings.currency)}</span>
              </div>
              {cartDiscount > 0 && (
                <div className="flex justify-between text-emerald-600 font-bold">
                  <span>Coupon Discount</span>
                  <span>-{formatCurrency(cartDiscount, settings.currency)}</span>
                </div>
              )}
              <div className="flex justify-between">
                <span>Shipping ({deliveryMethod})</span>
                <span className="font-bold text-slate-900">
                  {shippingFee === 0 ? <span className="text-emerald-600">FREE</span> : formatCurrency(shippingFee, settings.currency)}
                </span>
              </div>
              <div className="pt-2 border-t border-slate-200 flex justify-between items-baseline font-black">
                <span className="text-sm text-slate-900">Total Payable</span>
                <span className="text-lg text-blue-600">{formatCurrency(grandTotal, settings.currency)}</span>
              </div>
            </div>

            <div className="p-3 bg-blue-50/70 rounded-2xl border border-blue-100 text-[11px] text-slate-600 space-y-1">
              <p className="font-bold text-blue-900 flex items-center gap-1.5">
                <ShieldCheck size={14} className="text-blue-600" /> Buyer Protection Guarantee
              </p>
              <p>Your order is protected with authentic product verification and 7-day hassle-free replacement.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
