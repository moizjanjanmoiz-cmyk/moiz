import React, { useState } from 'react';
import Link from 'next/link';
import { demoShops } from '@/lib/demo-shops';
import { Store, ArrowUpRight, ArrowRight, MapPin, Sparkles, ShieldCheck } from 'lucide-react';

export const DemoShopsPage: React.FC = () => {
  const [selectedCity, setSelectedCity] = useState<string>('all');

  const filteredShops = demoShops.filter((s) => {
    if (selectedCity !== 'all' && s.city.toLowerCase() !== selectedCity.toLowerCase()) {
      return false;
    }
    return true;
  });

  return (
    <div className="py-8 sm:py-12 bg-slate-50 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        {/* Header */}
        <div className="flex flex-wrap justify-between items-end gap-4 pb-6 border-b border-slate-200">
          <div>
            <nav className="flex items-center gap-2 text-xs text-slate-500 font-medium mb-1">
              <Link href="/" className="hover:text-blue-600">Home</Link>
              <span>/</span>
              <span className="text-slate-900 font-bold">Independent Shops</span>
            </nav>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-700 text-[10px] font-black uppercase tracking-wider">
                FEATURED STOREFRONTS
              </span>
            </div>
            <h1 className="text-3xl sm:text-4xl font-black text-slate-900">
              Verified Seller Storefronts
            </h1>
            <p className="text-xs sm:text-sm text-slate-500 mt-1 max-w-xl">
              Explore bespoke Pakistani brands with direct seller WhatsApp communication, verified local inventory and specialized collections.
            </p>
          </div>

          <Link
            href="/open-shop"
            className="px-5 py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold text-xs flex items-center gap-2 shadow-md shadow-blue-500/20"
          >
            <Store size={16} /> Open Your Shop on Mega Bazar
          </Link>
        </div>

        {/* Demo Notice Banner */}
        <div className="rounded-2xl border border-amber-200 bg-amber-50/80 p-4 sm:p-5 flex items-center justify-between gap-4 text-xs text-amber-950">
          <div className="flex items-center gap-3">
            <Sparkles size={20} className="text-amber-600 shrink-0" />
            <div>
              <p className="font-extrabold">Illustrated Demo Storefront Previews</p>
              <p className="text-amber-800 text-[11px] mt-0.5">
                These shops illustrate the branding, collection showcase, and custom URL format for Mega Bazar sellers.
              </p>
            </div>
          </div>
          <span className="hidden sm:inline-block px-3 py-1 bg-amber-200 text-amber-900 rounded-lg text-[10px] font-black uppercase">
            Preview Mode
          </span>
        </div>

        {/* City Filter Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
          <button
            onClick={() => setSelectedCity('all')}
            className={`px-3.5 py-1.5 rounded-xl font-bold transition-all ${
              selectedCity === 'all' ? 'bg-slate-900 text-white' : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
            }`}
          >
            All Cities
          </button>
          {['Karachi', 'Lahore', 'Islamabad', 'Faisalabad'].map((city) => (
            <button
              key={city}
              onClick={() => setSelectedCity(city)}
              className={`px-3.5 py-1.5 rounded-xl font-bold transition-all flex items-center gap-1 ${
                selectedCity === city ? 'bg-blue-600 text-white' : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
              }`}
            >
              <MapPin size={12} /> {city}
            </button>
          ))}
        </div>

        {/* Shops Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredShops.map((s) => (
            <div
              key={s.slug}
              className="group rounded-3xl border border-slate-200 bg-white overflow-hidden shadow-xs hover:shadow-xl transition-all duration-300 flex flex-col justify-between"
            >
              <div>
                {/* Banner & Cover */}
                <div className="relative aspect-[16/9] bg-slate-100 overflow-hidden">
                  <img
                    src={s.image}
                    alt={`${s.name} collection`}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/70 via-transparent to-transparent" />
                  <span className="absolute top-3 left-3 rounded-full bg-white/95 px-2.5 py-0.5 text-[10px] font-black tracking-wider text-slate-700 shadow-xs">
                    VERIFIED SELLER
                  </span>
                  <div className="absolute bottom-3 left-3 text-white">
                    <p className="text-[11px] font-semibold text-white/80">{s.city} · {s.category}</p>
                  </div>
                </div>

                <div className="p-6">
                  {/* Monogram Badge */}
                  <div
                    style={{ background: s.color }}
                    className="-mt-12 relative w-14 h-14 rounded-2xl border-4 border-white shadow-md grid place-items-center text-white font-black text-base"
                  >
                    {s.initials}
                  </div>

                  <div className="flex justify-between items-start gap-2 mt-3">
                    <div>
                      <h3 className="font-black text-lg text-slate-900 group-hover:text-blue-600 transition-colors">
                        {s.name}
                      </h3>
                      <p className="text-xs text-blue-600 font-bold mt-0.5">{s.tagline}</p>
                    </div>
                  </div>

                  <p className="text-xs text-slate-500 leading-relaxed mt-2.5 line-clamp-2">
                    {s.description}
                  </p>

                  {/* Sample items pill */}
                  <div className="mt-4 pt-3 border-t border-slate-100 space-y-1.5">
                    <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Sample Catalogue:</p>
                    <div className="space-y-1">
                      {s.products.map((p) => (
                        <div key={p.name} className="flex justify-between text-xs text-slate-700">
                          <span className="truncate pr-2">{p.name}</span>
                          <span className="font-extrabold text-slate-900 shrink-0">PKR {p.price.toLocaleString('en-PK')}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              <div className="p-6 pt-0">
                <Link
                  href={`/demo-shops/${s.slug}`}
                  className="w-full py-2.5 px-4 bg-slate-900 hover:bg-blue-600 text-white rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-colors"
                >
                  Visit Storefront <ArrowRight size={14} />
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
