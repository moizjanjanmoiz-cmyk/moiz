import React from 'react';
import { SellerOnboarding } from '@/components/SellerOnboarding';

export const OpenShopPage: React.FC = () => {
  return <SellerOnboarding />;
};
