import React, { useState } from 'react';
import Link from 'next/link';
import { useStore } from '@/context/StoreContext';
import { formatCurrency } from '@/lib/utils';
import { Trash2, Plus, Minus, ArrowRight, ShoppingBag, ShieldCheck, Truck, Sparkles, Tag, ArrowLeft } from 'lucide-react';

export const CartPage: React.FC = () => {
  const {
    cart,
    updateCartQuantity,
    removeFromCart,
    clearCart,
    cartSubtotal,
    cartDiscount,
    cartGrandTotal,
    activeCoupon,
    applyCoupon,
    removeCoupon,
    settings,
  } = useStore();

  const [couponInput, setCouponInput] = useState('');
  const [couponError, setCouponError] = useState('');

  const freeShippingThreshold = settings.freeShippingThreshold || 5000;
  const isFreeShipping = cartSubtotal >= freeShippingThreshold;
  const shippingFee = cart.length === 0 ? 0 : isFreeShipping ? 0 : (settings.standardShippingFee || 250);
  const finalTotal = Math.max(0, cartSubtotal - cartDiscount + shippingFee);

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    setCouponError('');
    if (!couponInput.trim()) return;
    const res = applyCoupon(couponInput.trim().toUpperCase());
    if (!res || !res.success) {
      setCouponError(res?.message || 'Invalid coupon code. Try WELCOME10 or MEGA500');
    } else {
      setCouponInput('');
    }
  };

  return (
    <div className="py-8 sm:py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        {/* Breadcrumb */}
        <div>
          <nav className="flex items-center gap-2 text-xs text-slate-500 font-medium mb-1">
            <Link href="/" className="hover:text-blue-600">Home</Link>
            <span>/</span>
            <span className="text-slate-900 font-bold">Shopping Cart</span>
          </nav>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-900">Your Shopping Cart ({cart.length})</h1>
        </div>

        {cart.length === 0 ? (
          <div className="bg-white rounded-3xl p-12 text-center border border-slate-200 shadow-xs max-w-lg mx-auto">
            <div className="w-16 h-16 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center mx-auto mb-4">
              <ShoppingBag size={32} />
            </div>
            <h2 className="text-xl font-black text-slate-900">Your cart is empty</h2>
            <p className="text-xs text-slate-500 mt-2 leading-relaxed">
              Looks like you haven't added anything to your cart yet. Explore our wide range of products across Pakistan!
            </p>
            <Link
              href="/products"
              className="mt-6 inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs px-6 py-3 rounded-xl shadow-md transition-all"
            >
              Start Shopping <ArrowRight size={16} />
            </Link>
          </div>
        ) : (
          <div className="grid lg:grid-cols-[1fr_360px] gap-8 items-start">
            {/* Left: Cart Items List */}
            <div className="space-y-4">
              {/* Free Shipping Progress Indicator */}
              <div className="bg-white p-4 sm:p-5 rounded-2xl border border-blue-100 shadow-2xs space-y-2">
                <div className="flex items-center justify-between text-xs font-bold">
                  <span className="flex items-center gap-1.5 text-slate-800">
                    <Truck size={16} className="text-blue-600" />
                    {isFreeShipping ? (
                      <span className="text-emerald-600 font-black">🎉 Congratulations! You unlocked FREE delivery</span>
                    ) : (
                      <span>Add {formatCurrency(freeShippingThreshold - cartSubtotal, settings.currency)} more for FREE shipping</span>
                    )}
                  </span>
                  <span className="text-slate-500 font-medium">{Math.min(100, Math.round((cartSubtotal / freeShippingThreshold) * 100))}%</span>
                </div>
                <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                  <div
                    className={`h-full transition-all duration-500 ${isFreeShipping ? 'bg-emerald-500' : 'bg-blue-600'}`}
                    style={{ width: `${Math.min(100, (cartSubtotal / freeShippingThreshold) * 100)}%` }}
                  />
                </div>
              </div>

              {/* Items Card List */}
              <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs divide-y divide-slate-100 overflow-hidden">
                {cart.map((item) => (
                  <div key={`${item.productId}-${item.selectedSize || 'default'}`} className="p-4 sm:p-5 flex gap-4 items-center">
                    <Link href={`/product/${item.productId}`} className="w-20 h-20 sm:w-24 sm:h-24 rounded-xl bg-slate-50 overflow-hidden shrink-0 border border-slate-100">
                      <img
                        src={item.product.images?.[0] || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=400&q=80'}
                        alt={item.product.name}
                        className="w-full h-full object-cover"
                      />
                    </Link>

                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between items-start gap-2">
                        <div>
                          <p className="text-[10px] font-bold uppercase tracking-wider text-blue-600">{item.product.category}</p>
                          <Link href={`/product/${item.productId}`} className="text-xs sm:text-sm font-bold text-slate-800 hover:text-blue-600 line-clamp-1">
                            {item.product.name}
                          </Link>
                          {item.selectedSize && (
                            <span className="inline-block text-[10px] font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded mt-1">
                              Size: {item.selectedSize}
                            </span>
                          )}
                        </div>
                        <button
                          onClick={() => removeFromCart(item.productId, item.selectedSize)}
                          className="text-slate-400 hover:text-rose-500 p-1"
                          title="Remove item"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>

                      <div className="flex items-center justify-between gap-2 mt-3">
                        <div className="flex items-center border border-slate-200 rounded-lg bg-slate-50">
                          <button
                            onClick={() => updateCartQuantity(item.productId, item.quantity - 1, item.selectedSize)}
                            className="w-7 h-7 flex items-center justify-center text-slate-600 hover:bg-white"
                          >
                            <Minus size={13} />
                          </button>
                          <span className="w-8 text-center text-xs font-bold text-slate-800">{item.quantity}</span>
                          <button
                            onClick={() => updateCartQuantity(item.productId, item.quantity + 1, item.selectedSize)}
                            className="w-7 h-7 flex items-center justify-center text-slate-600 hover:bg-white"
                          >
                            <Plus size={13} />
                          </button>
                        </div>

                        <div className="text-right">
                          <p className="text-xs sm:text-sm font-extrabold text-slate-900">
                            {formatCurrency(item.product.price * item.quantity, settings.currency)}
                          </p>
                          {item.quantity > 1 && (
                            <p className="text-[10px] text-slate-400">
                              {formatCurrency(item.product.price, settings.currency)} each
                            </p>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="flex justify-between items-center pt-2">
                <Link href="/products" className="inline-flex items-center gap-1.5 text-xs font-bold text-blue-600 hover:underline">
                  <ArrowLeft size={14} /> Continue Shopping
                </Link>
                <button
                  onClick={clearCart}
                  className="text-xs font-semibold text-rose-600 hover:underline"
                >
                  Clear Entire Cart
                </button>
              </div>
            </div>

            {/* Right: Order Summary */}
            <div className="bg-white p-5 sm:p-6 rounded-2xl border border-slate-200/80 shadow-xs space-y-5 sticky top-24">
              <h2 className="text-base font-black text-slate-900 pb-3 border-b border-slate-100">Order Summary</h2>

              {/* Coupon Code Section */}
              <div>
                <form onSubmit={handleApplyCoupon} className="flex gap-2">
                  <div className="relative flex-1">
                    <input
                      type="text"
                      value={couponInput}
                      onChange={(e) => setCouponInput(e.target.value)}
                      placeholder="Promo code (e.g. MEGA500)"
                      className="w-full pl-8 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs uppercase font-medium focus:bg-white focus:border-blue-500 outline-hidden"
                    />
                    <Tag size={14} className="text-slate-400 absolute left-2.5 top-2.5" />
                  </div>
                  <button type="submit" className="px-4 py-2 bg-slate-900 text-white rounded-xl text-xs font-bold hover:bg-slate-800">
                    Apply
                  </button>
                </form>
                {couponError && <p className="text-[11px] text-rose-500 mt-1">{couponError}</p>}
                {activeCoupon && (
                  <div className="mt-2 p-2 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-between text-xs text-emerald-800 font-bold">
                    <span>Coupon {activeCoupon.code} applied!</span>
                    <button onClick={removeCoupon} className="text-rose-500 hover:underline text-[11px]">Remove</button>
                  </div>
                )}
              </div>

              {/* Subtotal Calculations */}
              <div className="space-y-2.5 text-xs text-slate-600 pt-2 border-t border-slate-100">
                <div className="flex justify-between">
                  <span>Subtotal ({cart.reduce((s, i) => s + i.quantity, 0)} items)</span>
                  <span className="font-bold text-slate-900">{formatCurrency(cartSubtotal, settings.currency)}</span>
                </div>

                {cartDiscount > 0 && (
                  <div className="flex justify-between text-emerald-600 font-semibold">
                    <span>Discount Savings</span>
                    <span>-{formatCurrency(cartDiscount, settings.currency)}</span>
                  </div>
                )}

                <div className="flex justify-between">
                  <span>Shipping Fee</span>
                  <span className="font-bold text-slate-900">
                    {shippingFee === 0 ? <span className="text-emerald-600">FREE</span> : formatCurrency(shippingFee, settings.currency)}
                  </span>
                </div>

                <div className="pt-3 border-t border-slate-200 flex justify-between items-baseline">
                  <span className="text-sm font-black text-slate-900">Grand Total</span>
                  <div className="text-right">
                    <span className="text-lg font-black text-blue-600">{formatCurrency(finalTotal, settings.currency)}</span>
                    <p className="text-[10px] text-slate-400">Includes all applicable duties & taxes</p>
                  </div>
                </div>
              </div>

              {/* Checkout Button */}
              <Link
                href="/checkout"
                className="w-full py-3.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold text-sm flex items-center justify-center gap-2 shadow-md shadow-blue-500/25 transition-all"
              >
                Proceed to Checkout <ArrowRight size={17} />
              </Link>

              {/* Trust Guarantee */}
              <div className="pt-3 border-t border-slate-100 flex items-center gap-2 text-[11px] text-slate-500">
                <ShieldCheck size={16} className="text-emerald-600 shrink-0" />
                <span>Cash on Delivery (COD) & EasyPaisa/JazzCash accepted across Pakistan</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
