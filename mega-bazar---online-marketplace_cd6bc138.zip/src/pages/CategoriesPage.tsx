import React from 'react';
import Link from 'next/link';
import { useStore } from '@/context/StoreContext';
import { MARKETPLACE_CATEGORIES } from '@/lib/marketplace-categories';
import { Package, ArrowRight, Sparkles, Layers } from 'lucide-react';

export const CategoriesPage: React.FC = () => {
  const { categories, products } = useStore();

  return (
    <div className="py-8 sm:py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        {/* Header */}
        <div>
          <nav className="flex items-center gap-2 text-xs text-slate-500 font-medium mb-2">
            <Link href="/" className="hover:text-blue-600">Home</Link>
            <span>/</span>
            <span className="text-slate-900 font-bold">Categories</span>
          </nav>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-700 text-[10px] font-black uppercase tracking-wider">
              MARKETPLACE DIRECTORY
            </span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-black text-slate-900 mt-2">Browse All Categories</h1>
          <p className="text-sm text-slate-600 mt-1 max-w-xl">
            Explore 24+ comprehensive merchandise categories across fashion, tech, household, personal care and lifestyle.
          </p>
        </div>

        {/* Primary Categories Grid with Images */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
          {categories.map((cat) => {
            const count = products.filter((p) => p.category.toLowerCase() === cat.name.toLowerCase()).length;
            return (
              <Link
                key={cat.id}
                href={`/category/${cat.slug}`}
                className="group relative rounded-2xl overflow-hidden bg-slate-900 text-white aspect-[4/5] flex flex-col justify-end p-4 shadow-sm hover:shadow-xl transition-all"
              >
                <img
                  src={cat.image}
                  alt={cat.name}
                  className="absolute inset-0 w-full h-full object-cover opacity-60 group-hover:scale-108 group-hover:opacity-75 transition-all duration-300"
                />
                <div className="relative z-10">
                  <h3 className="font-extrabold text-sm leading-snug drop-shadow-sm">{cat.name}</h3>
                  <p className="text-[11px] text-blue-200 mt-0.5 font-medium">{count > 0 ? `${count} Products` : `${cat.count.toLocaleString()} items`}</p>
                </div>
              </Link>
            );
          })}
        </div>

        {/* Full 24-Category Breakdown with Subcategories */}
        <div className="space-y-4 pt-4 border-t border-slate-200">
          <div className="flex items-center gap-2">
            <Layers size={20} className="text-blue-600" />
            <h2 className="text-2xl font-black text-slate-900">Department Directory & Subcategories</h2>
          </div>

          <div className="grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {Object.entries(MARKETPLACE_CATEGORIES).map(([catName, subs]) => (
              <div key={catName} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs hover:border-blue-400 transition-colors">
                <Link
                  href={`/products?category=${encodeURIComponent(catName)}`}
                  className="font-black text-slate-900 hover:text-blue-600 text-sm flex items-center justify-between group mb-3"
                >
                  <span>{catName}</span>
                  <ArrowRight size={14} className="text-slate-400 group-hover:text-blue-600 group-hover:translate-x-1 transition-all" />
                </Link>

                {subs && subs.length > 0 ? (
                  <div className="flex flex-wrap gap-1.5">
                    {subs.map((sub) => (
                      <Link
                        key={sub}
                        href={`/products?category=${encodeURIComponent(catName)}&q=${encodeURIComponent(sub)}`}
                        className="text-[11px] px-2.5 py-1 bg-slate-50 hover:bg-blue-50 text-slate-600 hover:text-blue-600 rounded-lg transition-colors"
                      >
                        {sub}
                      </Link>
                    ))}
                  </div>
                ) : (
                  <p className="text-[11px] text-slate-400">General marketplace merchandise</p>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
