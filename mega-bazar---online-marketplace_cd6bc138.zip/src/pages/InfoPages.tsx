import React, { useState } from 'react';
import Link from 'next/link';
import { useStore } from '@/context/StoreContext';
import { createWhatsAppLink } from '@/lib/whatsapp';
import {
  Mail,
  Phone,
  MapPin,
  MessageCircle,
  ShieldCheck,
  HelpCircle,
  CheckCircle,
  Store,
  Send,
  Eye,
  EyeOff,
  Lock,
  KeyRound,
  X,
  AlertCircle,
  ArrowRight,
} from 'lucide-react';
import { useRouter } from 'next/navigation';
import { supabase, isSupabaseConfigured } from '@/lib/supabase/client';
import { marketplaceEnabled } from '@/lib/marketplace/browser';

export const AboutPage: React.FC = () => {
  return (
    <div className="py-12 sm:py-16 bg-slate-50 min-h-screen">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 space-y-6">
        <div className="bg-white p-8 sm:p-10 rounded-3xl border border-slate-200 shadow-xs space-y-4">
          <span className="px-3 py-1 bg-blue-100 text-blue-700 text-xs font-black uppercase tracking-wider rounded-full">
            ABOUT MEGA BAZAR
          </span>
          <h1 className="text-3xl sm:text-4xl font-black text-slate-900">Pakistan's Trusted Online Marketplace</h1>
          <p className="text-sm text-slate-600 leading-relaxed">
            Mega Bazar is an e-commerce platform built to connect Pakistani buyers and independent merchants. We provide access to high-quality fashion, latest electronics, lifestyle essentials, and specialty goods with nationwide courier fulfillment and Cash on Delivery (COD).
          </p>
          <div className="grid sm:grid-cols-3 gap-4 pt-4 border-t border-slate-100 text-center">
            <div className="p-4 bg-slate-50 rounded-2xl">
              <p className="text-2xl font-black text-blue-600">100%</p>
              <p className="text-xs font-bold text-slate-700 mt-1">Authentic Products</p>
            </div>
            <div className="p-4 bg-slate-50 rounded-2xl">
              <p className="text-2xl font-black text-emerald-600">Nationwide</p>
              <p className="text-xs font-bold text-slate-700 mt-1">Cash on Delivery</p>
            </div>
            <div className="p-4 bg-slate-50 rounded-2xl">
              <p className="text-2xl font-black text-amber-600">7 Days</p>
              <p className="text-xs font-bold text-slate-700 mt-1">Easy Return Guarantee</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export const ContactPage: React.FC = () => {
  const { settings } = useStore();
  const [name, setName] = useState('');
  const [msg, setMsg] = useState('');
  const [sent, setSent] = useState(false);

  const waLink = createWhatsAppLink(settings.whatsappNumber || '923182204441', 'Hello! I would like to contact the Mega Bazar Help Desk.');

  return (
    <div className="py-12 sm:py-16 bg-slate-50 min-h-screen">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 space-y-8">
        <div className="text-center space-y-2">
          <h1 className="text-3xl sm:text-4xl font-black text-slate-900">Contact & Support Desk</h1>
          <p className="text-xs sm:text-sm text-slate-500">We are here to assist you with orders, returns, and seller onboarding.</p>
        </div>

        <div className="grid md:grid-cols-2 gap-6 items-start">
          <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-xs space-y-5">
            <h2 className="text-lg font-black text-slate-900">Direct Contact Information</h2>
            <div className="space-y-4 text-xs">
              <div className="flex items-center gap-3 text-slate-700">
                <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
                  <Phone size={18} />
                </div>
                <div>
                  <p className="font-bold text-slate-900">WhatsApp / Helpline</p>
                  <p className="text-slate-500">+92 318 2204441</p>
                </div>
              </div>

              <div className="flex items-center gap-3 text-slate-700">
                <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
                  <Mail size={18} />
                </div>
                <div>
                  <p className="font-bold text-slate-900">Official Email</p>
                  <p className="text-slate-500">{settings.contactEmail || 'moizziom84@gmail.com'}</p>
                </div>
              </div>

              <div className="flex items-center gap-3 text-slate-700">
                <div className="w-9 h-9 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center shrink-0">
                  <MapPin size={18} />
                </div>
                <div>
                  <p className="font-bold text-slate-900">Headquarters</p>
                  <p className="text-slate-500">Mega Bazar E-Commerce, Karachi, Pakistan</p>
                </div>
              </div>
            </div>

            <div className="pt-2">
              <a
                href={waLink}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-3 bg-[#25D366] hover:bg-[#20ba5a] text-white rounded-xl font-bold text-xs flex items-center justify-center gap-2 shadow-xs transition-all"
              >
                <MessageCircle size={17} className="fill-current" /> Open Instant WhatsApp Chat
              </a>
            </div>
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              setSent(true);
            }}
            className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-xs space-y-4 text-xs"
          >
            <h2 className="text-lg font-black text-slate-900">Send an Inquiry</h2>
            <div>
              <label className="font-bold text-slate-700 block mb-1">Your Name</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Muhammad Ali"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
              />
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1">Message</label>
              <textarea
                required
                rows={3}
                value={msg}
                onChange={(e) => setMsg(e.target.value)}
                placeholder="How can we help you?"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
              />
            </div>

            {sent ? (
              <div className="p-3 bg-emerald-50 text-emerald-800 rounded-xl font-bold flex items-center gap-2">
                <CheckCircle size={16} /> Thank you! Your message has been sent to support.
              </div>
            ) : (
              <button
                type="submit"
                className="w-full py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold flex items-center justify-center gap-1.5 shadow-xs"
              >
                <Send size={14} /> Send Message
              </button>
            )}
          </form>
        </div>
      </div>
    </div>
  );
};

export const PrivacyTermsPage: React.FC<{ type: 'privacy' | 'terms' }> = ({ type }) => {
  return (
    <div className="py-12 sm:py-16 bg-slate-50 min-h-screen">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 space-y-6 bg-white p-8 sm:p-10 rounded-3xl border border-slate-200 shadow-xs">
        <h1 className="text-2xl sm:text-3xl font-black text-slate-900">
          {type === 'privacy' ? 'Privacy Policy' : 'Terms & Conditions of Service'}
        </h1>
        <div className="space-y-4 text-xs sm:text-sm text-slate-600 leading-relaxed">
          <p>
            Welcome to Mega Bazar Pakistan. We respect customer privacy and are dedicated to safeguarding all personal information collected during order fulfillment, merchant registration, and delivery tracking.
          </p>
          <h2 className="font-bold text-sm text-slate-900 pt-2">1. Data Collection & Use</h2>
          <p>
            Customer names, contact numbers, and delivery addresses are utilized strictly for order verification, dispatch through verified courier services, and customer communication via WhatsApp.
          </p>
          <h2 className="font-bold text-sm text-slate-900 pt-2">2. Returns & Refunds</h2>
          <p>
            Customers have up to 7 days from the receipt date to initiate an exchange or return for damaged or incorrect goods.
          </p>
          <h2 className="font-bold text-sm text-slate-900 pt-2">3. Seller Responsibilities</h2>
          <p>
            Independent merchants on Mega Bazar guarantee genuine products, clear pricing in PKR, and timely order preparation.
          </p>
        </div>
      </div>
    </div>
  );
};

export const AuthPage: React.FC<{ mode: 'login' | 'register' }> = ({ mode }) => {
  const router = useRouter();
  const { login, verifyAdminCredentials, settings, updateAdminPassword, addNotification } = useStore();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [loginSuccessMessage, setLoginSuccessMessage] = useState('');

  // Forgot password modal state
  const [isForgotModalOpen, setIsForgotModalOpen] = useState(false);
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotStep, setForgotStep] = useState<'input_email' | 'set_new_password' | 'done'>('input_email');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [forgotError, setForgotError] = useState('');
  const [forgotSuccess, setForgotSuccess] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    setIsSubmitting(true);

    const cleanEmail = email.trim();
    const cleanPassword = password.trim();

    if (!cleanEmail || !cleanPassword) {
      setErrorMessage('Please enter both your email/phone and password.');
      setIsSubmitting(false);
      return;
    }

    if (mode === 'login') {
      const isOwnerAccount =
        cleanEmail.toLowerCase() === 'moizziom84@gmail.com' ||
        cleanEmail.toLowerCase() === 'admin@megabazar.pk' ||
        cleanEmail.toLowerCase() === 'admin' ||
        cleanEmail.toLowerCase() === (settings.adminEmail || '').toLowerCase();

      // 1. If Supabase is connected with live database credentials, use Supabase Auth
      if (isSupabaseConfigured) {
        try {
          const { data, error } = await supabase.auth.signInWithPassword({
            email: cleanEmail,
            password: cleanPassword,
          });

          if (error) {
            // If local owner verification matches, allow owner access as fallback
            if (isOwnerAccount) {
              const verified = await verifyAdminCredentials(cleanEmail, cleanPassword);
              if (verified) {
                setLoginSuccessMessage('Owner access verified! Redirecting to Super Admin Panel...');
                setTimeout(() => router.push('/admin'), 600);
                return;
              }
            }
            setErrorMessage(error.message || 'Invalid email or password. Please try again.');
            setIsSubmitting(false);
            return;
          }

          if (data?.user) {
            const appRole = (data.user.app_metadata?.role as string) || '';
            const userRole = (data.user.user_metadata?.role as string) || '';
            const isSuper = appRole === 'super_admin' || isOwnerAccount;
            const isSeller = appRole === 'seller' || userRole === 'seller';
            const displayName = data.user.user_metadata?.display_name || cleanEmail.split('@')[0];

            login(
              cleanEmail,
              isSuper ? 'super_admin' : isSeller ? 'seller' : 'customer',
              displayName
            );

            if (isSuper) {
              setLoginSuccessMessage('Super Admin authenticated! Redirecting to control panel...');
              setTimeout(() => router.push('/admin'), 600);
            } else if (isSeller) {
              setLoginSuccessMessage('Seller authenticated! Redirecting to your shop dashboard...');
              setTimeout(() => router.push('/seller/dashboard'), 600);
            } else {
              setLoginSuccessMessage('Signed in successfully! Redirecting...');
              setTimeout(() => router.push('/'), 600);
            }
            return;
          }
        } catch (err) {
          console.warn('Supabase signin attempt:', err);
        }
      }

      // 2. Local verification for Owner and standard customer
      if (isOwnerAccount) {
        const verified = await verifyAdminCredentials(cleanEmail, cleanPassword);
        if (verified) {
          setLoginSuccessMessage('Owner access verified! Redirecting to Super Admin Panel...');
          setTimeout(() => {
            router.push('/admin');
          }, 600);
          return;
        } else {
          setErrorMessage('Invalid owner credentials. Please check your password or use "Forgot Password?" below.');
          setIsSubmitting(false);
          return;
        }
      }

      // Regular customer authentication
      login(cleanEmail, 'customer');
      setLoginSuccessMessage('Successfully signed in!');
      setTimeout(() => {
        router.push('/');
      }, 600);
    } else {
      // Register Mode - strictly creates standard customer accounts (role: customer)
      if (cleanPassword.length < 6) {
        setErrorMessage('Password must be at least 6 characters long.');
        setIsSubmitting(false);
        return;
      }

      if (isSupabaseConfigured) {
        try {
          const { error } = await supabase.auth.signUp({
            email: cleanEmail,
            password: cleanPassword,
            options: {
              data: {
                role: 'customer',
                display_name: fullName.trim() || cleanEmail.split('@')[0],
                phone: phone.trim() || undefined,
              },
            },
          });
          if (error) {
            setErrorMessage(error.message || 'Registration failed.');
            setIsSubmitting(false);
            return;
          }
        } catch (err) {
          console.warn('Supabase signup attempt:', err);
        }
      }

      // Non-escalatable role assignment
      login(cleanEmail, 'customer', fullName.trim() || undefined);
      addNotification('Account Created', 'Welcome to Mega Bazar! Your customer account is ready.', 'system');
      setLoginSuccessMessage('Account created successfully! Redirecting...');
      setTimeout(() => {
        router.push('/');
      }, 700);
    }

    setIsSubmitting(false);
  };

  const handleForgotCheckEmail = (e: React.FormEvent) => {
    e.preventDefault();
    setForgotError('');
    setForgotSuccess('');

    const targetEmail = forgotEmail.trim().toLowerCase();
    if (!targetEmail) {
      setForgotError('Please enter your account email.');
      return;
    }

    const isOwner =
      targetEmail === 'moizziom84@gmail.com' ||
      targetEmail === 'admin@megabazar.pk' ||
      targetEmail === (settings.adminEmail || '').toLowerCase();

    if (isSupabaseConfigured) {
      supabase.auth.resetPasswordForEmail(targetEmail, {
        redirectTo: typeof window !== 'undefined' ? window.location.origin + '/reset-password' : '/reset-password',
      }).then(({ error }) => {
        if (error) {
          setForgotError(error.message || 'Could not send reset email.');
        } else {
          setForgotSuccess(`A secure password reset link has been dispatched to ${targetEmail}. Please check your inbox.`);
          setForgotStep('done');
        }
      }).catch((err) => {
        setForgotError(err instanceof Error ? err.message : 'Could not send reset email.');
      });
      return;
    }

    if (isOwner) {
      // Super Admin Owner Verified
      setForgotStep('set_new_password');
    } else {
      setForgotSuccess(`Password reset link has been dispatched to ${targetEmail}. Please check your inbox.`);
      setForgotStep('done');
    }
  };

  const handleResetOwnerPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setForgotError('');

    if (newPassword.length < 6) {
      setForgotError('New password must be at least 6 characters.');
      return;
    }
    if (newPassword !== confirmPassword) {
      setForgotError('Passwords do not match.');
      return;
    }

    try {
      await updateAdminPassword(newPassword);
      setForgotSuccess('Super Admin password successfully updated! You can now log in.');
      setForgotStep('done');
    } catch {
      setForgotError('Failed to update password. Please try again.');
    }
  };

  return (
    <div className="py-16 sm:py-24 bg-slate-50 min-h-screen flex items-center justify-center px-4">
      <div className="w-full max-w-md bg-white rounded-3xl p-7 sm:p-9 border border-slate-200 shadow-xl space-y-6">
        <div className="text-center space-y-2">
          <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mx-auto shadow-inner">
            <Lock size={22} />
          </div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight">
            {mode === 'login' ? 'Sign In to Mega Bazar' : 'Create Customer Account'}
          </h1>
          <p className="text-xs text-slate-500">
            {mode === 'login'
              ? 'Access orders, wishlist, seller workspace, and authorized portals'
              : 'Sign up to shop genuine Pakistani brands with verified cash on delivery'}
          </p>
        </div>

        {loginSuccessMessage ? (
          <div className="p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-2xl text-xs font-bold text-center space-y-2 animate-pulse">
            <CheckCircle size={26} className="mx-auto text-emerald-600" />
            <p>{loginSuccessMessage}</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4 text-xs">
            {mode === 'register' && (
              <>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Full Name</label>
                  <input
                    type="text"
                    required
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="Muhammad Ali"
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-blue-500 outline-hidden font-medium"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Mobile / WhatsApp (Optional)</label>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="03001234567"
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-blue-500 outline-hidden font-medium"
                  />
                </div>
              </>
            )}

            <div>
              <label className="font-bold text-slate-700 block mb-1">
                {mode === 'login' ? 'Email or Mobile Number' : 'Email Address'}
              </label>
              <input
                type="text"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder={mode === 'login' ? 'moizziom84@gmail.com or 03001234567' : 'name@example.com'}
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-blue-500 outline-hidden font-medium"
              />
            </div>

            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="font-bold text-slate-700">Password</label>
                {mode === 'login' && (
                  <button
                    type="button"
                    onClick={() => {
                      setForgotEmail(email || 'moizziom84@gmail.com');
                      setForgotStep('input_email');
                      setForgotError('');
                      setForgotSuccess('');
                      setIsForgotModalOpen(true);
                    }}
                    className="text-[11px] font-bold text-blue-600 hover:text-blue-700 hover:underline cursor-pointer"
                  >
                    Forgot Password?
                  </button>
                )}
              </div>

              {/* Password field: Masked by default with eye toggle */}
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••••••"
                  className="w-full px-4 py-2.5 pr-11 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-blue-500 outline-hidden font-medium tracking-wide"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700 p-1 cursor-pointer"
                >
                  {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            {errorMessage && (
              <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl text-xs font-semibold flex items-center gap-2">
                <AlertCircle size={15} className="shrink-0" />
                <span>{errorMessage}</span>
              </div>
            )}

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold shadow-xs transition-colors flex items-center justify-center gap-2 cursor-pointer disabled:opacity-60"
            >
              <span>{mode === 'login' ? 'Sign In' : 'Create Customer Account'}</span>
              <ArrowRight size={15} />
            </button>
          </form>
        )}

        <div className="text-center pt-2 text-xs text-slate-500 border-t border-slate-100">
          {mode === 'login' ? (
            <p>
              Don't have an account?{' '}
              <Link href="/register" className="font-bold text-blue-600 hover:underline">
                Register Customer Account
              </Link>
            </p>
          ) : (
            <p>
              Already registered?{' '}
              <Link href="/login" className="font-bold text-blue-600 hover:underline">
                Sign In
              </Link>
            </p>
          )}
        </div>
      </div>

      {/* Forgot Password Modal */}
      {isForgotModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-white rounded-3xl p-6 sm:p-8 shadow-2xl border border-slate-200 space-y-5 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex justify-between items-start">
              <div className="space-y-1">
                <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
                  <KeyRound size={20} />
                </div>
                <h2 className="text-lg font-black text-slate-900 pt-1">Account Password Recovery</h2>
                <p className="text-xs text-slate-500">Reset your master or customer account password</p>
              </div>
              <button
                type="button"
                onClick={() => setIsForgotModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-lg"
              >
                <X size={20} />
              </button>
            </div>

            {forgotError && (
              <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl text-xs font-semibold flex items-center gap-2">
                <AlertCircle size={15} className="shrink-0" />
                <span>{forgotError}</span>
              </div>
            )}

            {forgotStep === 'input_email' && (
              <form onSubmit={handleForgotCheckEmail} className="space-y-4 text-xs">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Account Email</label>
                  <input
                    type="email"
                    required
                    value={forgotEmail}
                    onChange={(e) => setForgotEmail(e.target.value)}
                    placeholder="moizziom84@gmail.com"
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-blue-500 outline-hidden font-medium"
                  />
                  <p className="text-[11px] text-slate-400 mt-1">
                    Enter the authorized email associated with your account.
                  </p>
                </div>
                <div className="flex justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setIsForgotModalOpen(false)}
                    className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl shadow-xs"
                  >
                    Verify Email
                  </button>
                </div>
              </form>
            )}

            {forgotStep === 'set_new_password' && (
              <form onSubmit={handleResetOwnerPassword} className="space-y-4 text-xs">
                <div className="p-3 bg-blue-50 border border-blue-200 rounded-xl text-blue-900 text-xs">
                  <p className="font-bold flex items-center gap-1.5">
                    <ShieldCheck size={16} className="text-blue-600" /> Owner Account Verified: {forgotEmail}
                  </p>
                  <p className="text-[11px] text-blue-700 mt-1">
                    Set a new secure master password for Super Admin access.
                  </p>
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">New Master Password</label>
                  <div className="relative">
                    <input
                      type={showNewPassword ? 'text' : 'password'}
                      required
                      minLength={6}
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      placeholder="Minimum 6 characters"
                      className="w-full px-4 py-2.5 pr-11 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-blue-500 outline-hidden font-medium"
                    />
                    <button
                      type="button"
                      onClick={() => setShowNewPassword(!showNewPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700 p-1 cursor-pointer"
                    >
                      {showNewPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">Confirm New Password</label>
                  <input
                    type={showNewPassword ? 'text' : 'password'}
                    required
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="Repeat new password"
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-blue-500 outline-hidden font-medium"
                  />
                </div>

                <div className="flex justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setForgotStep('input_email')}
                    className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl"
                  >
                    Back
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl shadow-xs"
                  >
                    Save New Password
                  </button>
                </div>
              </form>
            )}

            {forgotStep === 'done' && (
              <div className="space-y-4 text-center py-2">
                <div className="p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-2xl text-xs font-bold space-y-2">
                  <CheckCircle size={26} className="mx-auto text-emerald-600" />
                  <p>{forgotSuccess}</p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setIsForgotModalOpen(false);
                    setPassword(newPassword || '');
                  }}
                  className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl shadow-xs"
                >
                  Return to Sign In
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export const ResetPasswordPage: React.FC = () => {
  const router = useRouter();
  const { updateAdminPassword, addNotification } = useStore();
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  const handleUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    if (password.length < 6) {
      setErrorMessage('Password must be at least 6 characters.');
      return;
    }
    if (password !== confirmPassword) {
      setErrorMessage('Passwords do not match.');
      return;
    }

    setIsSubmitting(true);
    try {
      if (isSupabaseConfigured) {
        const { error } = await supabase.auth.updateUser({ password });
        if (error) {
          setErrorMessage(error.message || 'Failed to update password.');
          setIsSubmitting(false);
          return;
        }
      }
      await updateAdminPassword(password);
      setSuccessMessage('Your password has been successfully updated! Redirecting to login...');
      addNotification('Password Reset', 'Your account password has been updated.', 'system');
      setTimeout(() => {
        router.push('/login');
      }, 1500);
    } catch (err) {
      setErrorMessage(err instanceof Error ? err.message : 'Failed to update password.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="py-16 sm:py-24 bg-slate-50 min-h-screen flex items-center justify-center px-4">
      <div className="w-full max-w-md bg-white rounded-3xl p-7 sm:p-9 border border-slate-200 shadow-xl space-y-6">
        <div className="text-center space-y-2">
          <div className="w-12 h-12 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center mx-auto shadow-inner">
            <KeyRound size={22} />
          </div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight">Set New Password</h1>
          <p className="text-xs text-slate-500">Create a secure new password for your Mega Bazar account</p>
        </div>

        {successMessage ? (
          <div className="p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-2xl text-xs font-bold text-center space-y-2">
            <CheckCircle size={26} className="mx-auto text-emerald-600" />
            <p>{successMessage}</p>
          </div>
        ) : (
          <form onSubmit={handleUpdate} className="space-y-4 text-xs">
            <div>
              <label className="font-bold text-slate-700 block mb-1">New Password</label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  minLength={6}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Minimum 6 characters"
                  className="w-full px-4 py-2.5 pr-11 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-blue-500 outline-hidden font-medium"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700 p-1 cursor-pointer"
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                >
                  {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1">Confirm New Password</label>
              <input
                type={showPassword ? 'text' : 'password'}
                required
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Re-enter new password"
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-blue-500 outline-hidden font-medium"
              />
            </div>

            {errorMessage && (
              <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl text-xs font-semibold flex items-center gap-2">
                <AlertCircle size={15} className="shrink-0" />
                <span>{errorMessage}</span>
              </div>
            )}

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold shadow-xs transition-colors flex items-center justify-center gap-2 cursor-pointer disabled:opacity-60"
            >
              {isSubmitting ? 'Updating...' : 'Save New Password & Continue'}
            </button>
          </form>
        )}

        <div className="text-center pt-2 text-xs text-slate-500 border-t border-slate-100">
          <Link href="/login" className="font-bold text-blue-600 hover:underline">
            Back to Sign In
          </Link>
        </div>
      </div>
    </div>
  );
};

