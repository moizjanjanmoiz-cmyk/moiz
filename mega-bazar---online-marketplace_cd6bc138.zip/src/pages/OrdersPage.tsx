import React from 'react';
import Link from 'next/link';
import { useStore } from '@/context/StoreContext';
import { formatCurrency, createWhatsAppLink } from '@/lib/utils';
import { Package, Truck, MessageCircle, ArrowRight, ExternalLink } from 'lucide-react';

export const OrdersPage: React.FC = () => {
  const { orders, settings } = useStore();

  return (
    <div className="py-8 sm:py-12 bg-slate-50 min-h-screen">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 space-y-6">
        <div>
          <nav className="flex items-center gap-2 text-xs text-slate-500 font-medium mb-1">
            <Link href="/" className="hover:text-blue-600">Home</Link>
            <span>/</span>
            <span className="text-slate-900 font-bold">My Orders</span>
          </nav>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-900">Your Order History & Tracking</h1>
        </div>

        {orders.length === 0 ? (
          <div className="bg-white rounded-3xl p-12 text-center border border-slate-200 shadow-xs max-w-md mx-auto">
            <Package size={40} className="mx-auto text-slate-300 mb-3" />
            <h2 className="text-lg font-black text-slate-900">No Orders Yet</h2>
            <p className="text-xs text-slate-500 mt-1">Orders placed on this device will automatically show up here for live tracking.</p>
            <Link href="/products" className="mt-5 inline-block px-6 py-2.5 bg-blue-600 text-white rounded-xl text-xs font-bold">
              Shop Now
            </Link>
          </div>
        ) : (
          <div className="space-y-4">
            {orders.map((o) => {
              const waMessage = `Hello! I would like to check the tracking status of my order *${o.orderNumber}*. Thank you!`;
              const waUrl = createWhatsAppLink(settings.whatsappNumber || '923182204441', waMessage);

              return (
                <div key={o.id} className="bg-white p-5 sm:p-6 rounded-3xl border border-slate-200 shadow-xs space-y-4">
                  <div className="flex flex-wrap justify-between items-start gap-3 pb-3 border-b border-slate-100">
                    <div>
                      <span className="font-mono text-xs font-black text-blue-600 bg-blue-50 px-2.5 py-1 rounded-lg">
                        {o.orderNumber}
                      </span>
                      <p className="text-xs text-slate-500 mt-1.5">{o.createdAt}</p>
                    </div>

                    <div className="text-right">
                      <span className={`px-2.5 py-1 rounded-full text-xs font-extrabold uppercase ${
                        o.orderStatus === 'Delivered'
                          ? 'bg-emerald-100 text-emerald-800'
                          : o.orderStatus === 'Shipped'
                          ? 'bg-blue-100 text-blue-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}>
                        {o.orderStatus}
                      </span>
                      <p className="text-sm font-black text-slate-900 mt-1">{formatCurrency(o.grandTotal, settings.currency)}</p>
                    </div>
                  </div>

                  <div className="space-y-2">
                    {o.items?.map((item, idx) => (
                      <div key={idx} className="flex items-center justify-between text-xs text-slate-700">
                        <span className="font-medium truncate pr-4">{item.name} × {item.quantity}</span>
                        <span className="font-bold text-slate-900 shrink-0">{formatCurrency(item.price * item.quantity, settings.currency)}</span>
                      </div>
                    ))}
                  </div>

                  <div className="pt-3 border-t border-slate-100 flex flex-wrap justify-between items-center gap-3 text-xs">
                    <span className="text-slate-500">Destination: {o.shippingAddress?.city || 'Pakistan'}</span>
                    <div className="flex gap-2">
                      <a
                        href={waUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-3.5 py-1.5 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 rounded-lg font-bold flex items-center gap-1.5"
                      >
                        <MessageCircle size={14} /> WhatsApp Support
                      </a>
                      <Link
                        href={`/order-confirmation/${o.id}`}
                        className="px-3.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-bold"
                      >
                        Receipt
                      </Link>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
