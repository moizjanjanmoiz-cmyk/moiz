import React from 'react';
import Link from 'next/link';
import { motion, useReducedMotion } from 'motion/react';
import { ArrowRight, Store, ShoppingBag, Package, Share2, Sparkles, ShieldCheck, Truck, RefreshCw, Headphones, Zap, Crown } from 'lucide-react';
import { useStore } from '@/context/StoreContext';
import { HeroBanner } from '@/components/HeroBanner';
import { CategoryShortcuts } from '@/components/CategoryShortcuts';
import { FlashDeal } from '@/components/FlashDeal';
import { DemoShops } from '@/components/DemoShops';
import { PopularCategories } from '@/components/PopularCategories';
import { PromotionalBanners } from '@/components/PromotionalBanners';
import { LiveListings } from '@/components/LiveListings';
import { ProductCard } from '@/components/ProductCard';
import { Testimonials } from '@/components/Testimonials';
import { Newsletter } from '@/components/Newsletter';
import { showDemoShops } from '@/lib/demo-shops';
import { MARKETPLACE_CATEGORIES } from '@/lib/marketplace-categories';

export const HomePage: React.FC = () => {
  const { products } = useStore();
  const reduced = useReducedMotion();

  const featuredProducts = products.filter((p) => p.status === 'active' && (p.isFeatured || p.isBestSeller)).slice(0, 8);
  const regularProducts = products.filter((p) => p.status === 'active').slice(0, 12);

  return (
    <div className="pb-16 space-y-4 sm:space-y-6">
      {/* 1. Category Shortcuts */}
      <CategoryShortcuts />

      {/* 2. Hero Carousel Banner */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <HeroBanner />
      </div>

      {/* 3. Value Props Bar */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 bg-white p-4 sm:p-5 rounded-2xl border border-slate-100 shadow-xs">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs font-bold text-slate-800">Nationwide Delivery</p>
              <p className="text-[11px] text-slate-500">Across all Pakistan cities</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs font-bold text-slate-800">Cash on Delivery</p>
              <p className="text-[11px] text-slate-500">Pay when you receive</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center shrink-0">
              <RefreshCw className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs font-bold text-slate-800">7 Days Easy Return</p>
              <p className="text-[11px] text-slate-500">100% money back guarantee</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center shrink-0">
              <Headphones className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs font-bold text-slate-800">24/7 WhatsApp Support</p>
              <p className="text-[11px] text-slate-500">Instant seller assistance</p>
            </div>
          </div>
        </div>
      </section>

      {/* 4. Flash Deal Section */}
      <FlashDeal />

      {/* 5. Marketplace Mission Card */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="relative overflow-hidden rounded-[2rem] bg-slate-950 text-white p-7 sm:p-12 lg:p-14 shadow-xl">
          <div aria-hidden="true" className="absolute -right-20 -top-24 w-96 h-96 rounded-full bg-blue-600/30 blur-3xl pointer-events-none" />
          <div className="grid lg:grid-cols-[1.2fr_1fr] gap-10 items-center relative z-10">
            <motion.div initial={reduced ? false : { opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
              <span className="inline-flex items-center gap-2 text-xs font-bold tracking-widest text-blue-300 uppercase">
                <Sparkles size={16} /> PAKISTAN'S TRUSTED MULTI-VENDOR MARKETPLACE
              </span>
              <h1 className="mt-4 text-3xl sm:text-5xl lg:text-6xl font-black leading-[1.1] tracking-tight">
                Many shops.<br />
                <span className="text-blue-400">One Mega Bazar.</span>
              </h1>
              <p className="mt-4 text-slate-300 leading-relaxed max-w-lg text-sm sm:text-base">
                Discover authentic products across electronics, fashion, beauty and home essentials from verified sellers. Open your own online shop and reach buyers nationwide.
              </p>
              <div className="flex flex-wrap gap-3 mt-7">
                <Link href="/products" className="bg-blue-600 hover:bg-blue-500 text-white rounded-xl px-6 py-3 font-bold text-sm inline-flex gap-2 items-center shadow-lg shadow-blue-600/30 transition-all">
                  Explore Catalogue <ArrowRight size={17} />
                </Link>
                <Link href="/open-shop" className="bg-white/10 hover:bg-white/20 border border-white/20 text-white rounded-xl px-6 py-3 font-bold text-sm transition-all">
                  Open Your Shop
                </Link>
              </div>
            </motion.div>

            <motion.div initial={reduced ? false : { opacity: 0, y: 25 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.1 }} className="grid grid-cols-2 gap-3 sm:gap-4">
              <div className="col-span-2 rounded-2xl bg-white text-slate-900 p-5 sm:p-6 shadow-xl">
                <div className="flex gap-4 items-center">
                  <div className="bg-blue-50 p-3.5 rounded-2xl text-blue-600 shrink-0">
                    <Store size={28} />
                  </div>
                  <div>
                    <p className="font-black text-base sm:text-lg">A Space for Your Business</p>
                    <p className="text-xs text-slate-500 mt-0.5">Your brand. Your products. Your verified storefront.</p>
                  </div>
                </div>
                <div className="mt-4 rounded-xl bg-slate-50 border border-slate-200/80 p-3 text-xs font-mono text-slate-600 break-all flex items-center justify-between">
                  <span>megabazaar.com/shop/your-shop</span>
                  <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded">Ready</span>
                </div>
                <Link href="/shop/preview" className="mt-3 inline-flex gap-2 text-xs font-bold text-blue-600 hover:text-blue-700 items-center">
                  Preview Demo Storefronts <ArrowRight size={15} />
                </Link>
              </div>

              {[
                { Icon: ShoppingBag, title: 'Shop by Category', text: '24+ Curated categories', href: '/categories' },
                { Icon: Share2, title: 'Share Your Shop', text: 'Dedicated link for customers', href: '/open-shop' },
              ].map(({ Icon, title, text, href }) => (
                <Link key={title} href={href} className="rounded-2xl p-4 bg-white/10 border border-white/15 hover:bg-white/20 transition-all flex flex-col justify-between">
                  <Icon className="text-blue-300" size={24} />
                  <div className="mt-3">
                    <h2 className="font-bold text-sm text-white">{title}</h2>
                    <p className="text-[11px] text-slate-300 mt-1">{text}</p>
                  </div>
                </Link>
              ))}
            </motion.div>
          </div>
        </div>
      </section>

      {/* 6. Popular Categories */}
      <PopularCategories />

      {/* 7. Promotional Banners */}
      <PromotionalBanners />

      {/* 8. Demo Shops Preview Section */}
      {showDemoShops && <DemoShops />}

      {/* 9. Live Listings */}
      <LiveListings />

      {/* 10. Featured & Best Seller Products */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex flex-wrap justify-between items-center mb-6 gap-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-700 text-[10px] font-black uppercase tracking-wider">
                TOP PICKS
              </span>
              <span className="flex items-center gap-1 text-xs text-amber-600 font-bold">
                <Zap size={14} className="fill-amber-500" /> Best Sellers in Pakistan
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 mt-1">Featured Products</h2>
          </div>
          <Link href="/products" className="text-blue-600 hover:text-blue-700 text-sm font-bold flex items-center gap-1">
            View All ({products.length}) <ArrowRight size={16} />
          </Link>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4 lg:gap-5">
          {(featuredProducts.length > 0 ? featuredProducts : regularProducts.slice(0, 8)).map((p, i) => (
            <ProductCard key={p.id} product={p} priority={i < 4} />
          ))}
        </div>
      </section>

      {/* 11. Browse By Category Showcase */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex justify-between items-end gap-4 mb-6">
          <div>
            <p className="text-xs uppercase tracking-widest text-blue-600 font-bold">FIND YOUR EVERYDAY</p>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 mt-1">A Category for Every Need</h2>
          </div>
          <Link href="/categories" className="text-sm font-bold text-blue-600 hover:text-blue-700">
            View all 24+ →
          </Link>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
          {Object.keys(MARKETPLACE_CATEGORIES).slice(0, 8).map((c, i) => (
            <motion.div key={c} initial={reduced ? false : { opacity: 0, y: 12 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.03 }}>
              <Link href={`/products?category=${encodeURIComponent(c)}`} className="block h-full p-4 sm:p-5 bg-white border border-slate-200/80 rounded-2xl hover:border-blue-500 hover:shadow-md transition-all group">
                <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                  <Package size={20} />
                </div>
                <h3 className="font-bold text-sm text-slate-800 group-hover:text-blue-600 transition-colors">{c}</h3>
                <p className="text-[11px] text-slate-400 mt-1">
                  {MARKETPLACE_CATEGORIES[c].length > 0 ? `${MARKETPLACE_CATEGORIES[c].length} subcategories` : 'Explore items'}
                </p>
              </Link>
            </motion.div>
          ))}
        </div>
      </section>

      {/* 12. Full Catalogue Preview */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900">Explore the Marketplace</h2>
            <p className="text-xs text-slate-500 mt-1">Authentic goods with verified seller contacts and transparent pricing</p>
          </div>
          <Link href="/products" className="text-blue-600 hover:text-blue-700 text-sm font-bold">
            All products →
          </Link>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4 lg:gap-5">
          {regularProducts.map((p, i) => (
            <ProductCard key={p.id} product={p} priority={i < 4} />
          ))}
        </div>
      </section>

      {/* 13. Seller CTA Card */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-4">
        <div className="rounded-3xl border border-blue-200 bg-gradient-to-r from-blue-50 via-indigo-50 to-blue-50 p-8 sm:p-12 flex flex-wrap justify-between items-center gap-6 shadow-xs">
          <div className="max-w-xl">
            <span className="px-3 py-1 bg-blue-600 text-white rounded-full text-[10px] font-extrabold uppercase tracking-wider">
              SELL ON MEGA BAZAR
            </span>
            <h2 className="text-2xl sm:text-4xl font-black text-slate-900 mt-3">
              Ready to grow your business online?
            </h2>
            <p className="text-slate-600 text-sm mt-2 leading-relaxed">
              Open your verified digital storefront in minutes. Upload your products, share your personal shop link with customers, and accept direct orders via WhatsApp and online checkout.
            </p>
          </div>
          <div className="flex flex-wrap gap-3">
            <Link href="/open-shop" className="bg-blue-600 hover:bg-blue-500 text-white px-6 py-3.5 rounded-xl font-bold text-sm shadow-md transition-all">
              Start Shop Setup →
            </Link>
            <Link href="/shop/preview" className="bg-white hover:bg-slate-50 border border-slate-300 text-slate-800 px-6 py-3.5 rounded-xl font-bold text-sm transition-all">
              View Shop Samples
            </Link>
          </div>
        </div>
      </section>

      {/* 14. Customer Testimonials */}
      <Testimonials />

      {/* 15. Newsletter */}
      <Newsletter />
    </div>
  );
};
