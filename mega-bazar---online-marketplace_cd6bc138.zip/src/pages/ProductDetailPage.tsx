import React from 'react';
import { useParams } from '@/router/navigation';
import { useStore } from '@/context/StoreContext';
import { ProductDetailClient } from '@/components/ProductDetailClient';
import Link from 'next/link';
import { ArrowLeft } from 'lucide-react';

export const ProductDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { products } = useStore();

  const product = products.find((p) => p.id === id || p.slug === id);

  if (!id) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-16 text-center">
        <h2 className="text-xl font-bold text-slate-800">Product not specified</h2>
        <Link href="/products" className="mt-4 inline-flex items-center gap-2 text-blue-600 font-bold text-sm">
          <ArrowLeft size={16} /> Return to Products
        </Link>
      </div>
    );
  }

  return <ProductDetailClient initialProductId={id} initialProduct={product} />;
};
